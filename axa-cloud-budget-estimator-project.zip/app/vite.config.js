import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// SWA build output goes to app/dist — referenced in the GitHub Actions /
// Azure Pipelines `app_location: "app"` + `output_location: "dist"` config.
//
// Local dev: SWA CLI (`swa start`) proxies /api to func start on :7071.

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
  server: {
    port: 4280, // SWA CLI default
  },
});
