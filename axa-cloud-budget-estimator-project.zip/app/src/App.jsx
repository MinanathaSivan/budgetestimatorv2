import { useEffect, useState } from "react";
import { buildTheme } from "./theme.js";
import { CloudLogo } from "./components/UI.jsx";
import { Estimator } from "./pages/Estimator.jsx";
import { PricingPanel } from "./pages/PricingPanel.jsx";
import { IAM } from "./pages/IAM.jsx";
import { api, setCachedEmail, setCachedName } from "./lib/api.js";
import { buildRateCard } from "./lib/calc.js";
import { ROLES } from "./lib/constants.js";
import { login, logout, getClientPrincipal } from "./auth/swaAuth.js";

function DisclaimerModal({ onAccept, t }) {
  const [declining, setDeclining] = useState(false);
  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "rgba(0,0,0,0.65)", backdropFilter: "blur(8px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'DM Sans',sans-serif",
    }}>
      <div style={{
        background: t.card, border: `1px solid ${t.cardBorder}`, borderRadius: 20,
        padding: "36px 40px", maxWidth: 500, width: "90%", textAlign: "center",
        boxShadow: "0 24px 80px rgba(0,0,0,0.35)",
      }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>⚠️</div>
        <h2 style={{ margin: "0 0 12px", fontSize: 20, fontWeight: 800, color: t.text }}>Disclaimer</h2>
        <p style={{ fontSize: 14, lineHeight: 1.6, color: t.textSec, margin: "0 0 28px" }}>
          This tool provides <strong style={{ color: t.text }}>budget estimation only</strong>.
          All prices shown are indicative and exclude opCo VAT. Final costs may vary based on
          actual consumption, contractual agreements, and provider pricing changes.
        </p>
        {declining && (
          <div style={{
            padding: "12px 16px", borderRadius: 10, marginBottom: 20,
            background: "rgba(255,180,0,0.08)", border: "1px solid rgba(255,180,0,0.2)",
            fontSize: 13, color: "#E5A800",
          }}>
            You must agree to the disclaimer to use this tool.
          </div>
        )}
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <button onClick={onAccept} style={{
            padding: "12px 32px", borderRadius: 12, border: "none", cursor: "pointer",
            background: "linear-gradient(135deg, #00008F, #00A0E1)",
            color: "#fff", fontWeight: 700, fontSize: 14,
          }}>
            I Agree &amp; Continue
          </button>
          <button onClick={() => setDeclining(true)} style={{
            padding: "12px 24px", borderRadius: 12, cursor: "pointer",
            border: `1px solid ${t.inputBorder}`, background: t.card,
            color: t.textSec, fontWeight: 600, fontSize: 13,
          }}>
            Decline
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [stage, setStage] = useState("loading");
  const [me, setMe] = useState(null);
  const [rateCard, setRateCard] = useState({
    mpi: { dbServices: {} }, license: {}, nas: {}, pod: {}, terraform: {}, config: { fxRate: 1.10 },
  });
  const [activeTab, setActiveTab] = useState("estimator");
  const [dark, setDark] = useState(true);
  const [display, setDisplay] = useState("EUR");
  const [disclaimerAccepted, setDisclaimerAccepted] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const t = buildTheme(dark);

  const loadRateCard = async () => {
    try { setRateCard(buildRateCard(await api.getProducts())); }
    catch (e) { console.error(e); }
  };

  useEffect(() => {
    if (sessionStorage.getItem("disclaimerAccepted") === "true") {
      setDisclaimerAccepted(true);
    }
    (async () => {
      const principal = await getClientPrincipal();
      if (!principal) { setStage("signed-out"); return; }
      try {
        const claims = principal.claims || [];
        const claimBySuffix = (suffix) =>
          claims.find((c) => String(c.typ || "").split("/").pop().toLowerCase() === suffix);

        const emailClaim = claimBySuffix("emailaddress");
        if (emailClaim) setCachedEmail(emailClaim.val.toLowerCase());

        // Forward the display name too. The x-ms-client-principal header that
        // SWA sends to the Functions backend does not include `claims`, so the
        // API cannot read the name itself — only /.auth/me exposes it here.
        const nameClaim = claimBySuffix("name");
        if (nameClaim && nameClaim.val) setCachedName(String(nameClaim.val).trim());

        setMe(await api.getMe());
        await loadRateCard();
        setStage("ready");
      } catch (e) {
        console.error(e);
        setErrorMsg(e.message || "Something went wrong");
        setStage("error");
      }
    })();
  }, []);

  const handleAcceptDisclaimer = () => {
    sessionStorage.setItem("disclaimerAccepted", "true");
    setDisclaimerAccepted(true);
  };

  if (stage === "loading") {
    return <div style={{ minHeight: "100vh", background: t.bg, color: t.text, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans',sans-serif" }}>Loading…</div>;
  }
  if (stage === "signed-out") {
    return (
      <div style={{ minHeight: "100vh", background: t.bg, color: t.text, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans',sans-serif", padding: 32 }}>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        <div style={{ textAlign: "center", maxWidth: 420 }}>
          <div style={{ marginBottom: 16 }}><CloudLogo /></div>
          <h1 style={{ margin: "0 0 8px", fontSize: 26, fontWeight: 800 }}>AXA Cloud Budget Estimator</h1>
          <p style={{ color: t.textSec, fontSize: 13, margin: "0 0 24px" }}>Sign in with your AXA Entra ID account to continue.</p>
          <button onClick={() => login("/")} style={{ padding: "12px 28px", borderRadius: 12, border: "none", cursor: "pointer", background: "linear-gradient(135deg, #00008F, #00A0E1)", color: "#fff", fontWeight: 700, fontSize: 14 }}>Sign in with AXA</button>
        </div>
      </div>
    );
  }
  if (stage === "error") {
    return (
      <div style={{ minHeight: "100vh", background: t.bg, color: t.text, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans',sans-serif", padding: 32 }}>
        <div style={{ maxWidth: 480, textAlign: "center" }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>⚠️</div>
          <h2 style={{ margin: "0 0 8px" }}>Something went wrong</h2>
          <p style={{ color: t.textSec, fontSize: 13 }}>{errorMsg}</p>
          <button onClick={() => window.location.reload()} style={{ marginTop: 16, padding: "10px 20px", borderRadius: 10, border: "none", cursor: "pointer", background: "#00A0E1", color: "#fff", fontWeight: 700 }}>Retry</button>
        </div>
      </div>
    );
  }

  if (!disclaimerAccepted) {
    return (
      <>
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        <DisclaimerModal onAccept={handleAcceptDisclaimer} t={t} />
      </>
    );
  }

  const roleInfo = ROLES[me.role] || ROLES.user;
  const tabs = [
    { id: "estimator", label: "Cost Estimator", icon: "⚡", roles: ["user", "pricing_admin", "super_admin"] },
    { id: "pricing",   label: "Pricing Panel",  icon: "💰", roles: ["pricing_admin", "super_admin"] },
    { id: "iam",       label: "IAM Management", icon: "🛡", roles: ["super_admin"] },
  ].filter((tb) => tb.roles.includes(me.role));

  return (
    <div style={{ minHeight: "100vh", background: t.bg, fontFamily: "'DM Sans',sans-serif", color: t.text }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
      <div style={{ position: "sticky", top: 0, zIndex: 50, backdropFilter: "blur(24px)", background: t.header, borderBottom: `1px solid ${t.headerBorder}` }}>
        <div style={{ padding: "0 24px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <CloudLogo />
              <div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>AXA Cloud Budget Estimator</div>
                <div style={{ fontSize: 10, color: t.textSec }}>Budget estimation · excl. opCo VAT</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ display: "flex", border: `1px solid ${t.inputBorder}`, borderRadius: 10, overflow: "hidden" }}>
                {["EUR", "USD"].map((c) => (
                  <button key={c} onClick={() => setDisplay(c)} style={{ padding: "8px 12px", border: "none", cursor: "pointer", background: display === c ? "#00A0E1" : t.card, color: display === c ? "#fff" : t.textSec, fontSize: 11, fontWeight: 700 }}>{c}</button>
                ))}
              </div>
              <button onClick={() => setDark(!dark)} style={{ width: 36, height: 36, borderRadius: 10, border: `1px solid ${t.inputBorder}`, background: dark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.06)", cursor: "pointer", fontSize: 16, color: dark ? "#FFD966" : "#555", display: "flex", alignItems: "center", justifyContent: "center" }}>{dark ? "☀" : "🌙"}</button>
              <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 14px", borderRadius: 11, border: `1px solid ${t.inputBorder}`, background: t.card }}>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: `${roleInfo.color}18`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: roleInfo.color }}>{me.avatar}</div>
                <div style={{ textAlign: "left" }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: t.text }}>{me.name}</div>
                  <div style={{ fontSize: 10, color: roleInfo.color, fontWeight: 600 }}>{roleInfo.label}</div>
                </div>
              </div>
              <button onClick={logout} style={{ padding: "7px 14px", borderRadius: 10, border: `1px solid ${t.inputBorder}`, background: t.card, color: t.textSec, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>Sign out</button>
            </div>
          </div>
          <div style={{ display: "flex", gap: 2, borderTop: `1px solid ${t.divider}` }}>
            {tabs.map((tb) => (
              <button key={tb.id} onClick={() => setActiveTab(tb.id)} style={{ padding: "11px 20px", border: "none", cursor: "pointer", background: "transparent", color: activeTab === tb.id ? t.text : t.textSec, fontWeight: 600, fontSize: 13, borderBottom: activeTab === tb.id ? `2px solid ${roleInfo.color}` : "2px solid transparent", display: "flex", alignItems: "center", gap: 7 }}>
                <span style={{ fontSize: 14 }}>{tb.icon}</span>{tb.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div style={{ padding: "28px 24px 60px" }}>
        {activeTab === "estimator" && <Estimator rateCard={rateCard} currentUser={me} display={display} fxRate={rateCard.config.fxRate || 1.10} t={t} />}
        {activeTab === "pricing" && (me.role === "super_admin" || me.role === "pricing_admin") && <PricingPanel currentUser={me} onRateCardChanged={loadRateCard} t={t} />}
        {activeTab === "iam" && me.role === "super_admin" && <IAM t={t} />}
      </div>
    </div>
  );
}