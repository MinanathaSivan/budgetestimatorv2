import { useEffect, useState } from "react";
import { Card, Badge } from "../components/UI.jsx";
import { api } from "../lib/api.js";
import { fmt } from "../lib/currency.js";

// Groups the flat rate-card rows into readable sections
const GROUPS = [
  { id: "mpi_fixed",    title: "MPI — Fixed Fees",   prefix: "mpi_",       product: "mpi",       exclude: ["license", "dbServices", "backup"] },
  { id: "mpi_db",       title: "MPI — DB Services",  prefix: "mpi_dbServices_", product: "mpi" },
  { id: "mpi_license",  title: "MPI — Licenses",     prefix: "mpi_license_",    product: "mpi" },
  { id: "nas",          title: "NAS / Fileshare",    prefix: "nas_",            product: "nas" },
  { id: "pod",          title: "POD",                prefix: "pod_",            product: "pod" },
  { id: "terraform",    title: "Terraform Workspace",prefix: "terraform_",      product: "terraform" },
  { id: "config",       title: "Configuration (FX rate)", prefix: "config_",    product: null },
];

function matchGroup(row) {
  const k = row.rowKey;
  if (k === "config_fxRate") return "config";
  if (k.startsWith("nas_")) return "nas";
  if (k.startsWith("pod_")) return "pod";
  if (k.startsWith("terraform_")) return "terraform";
  if (k.startsWith("mpi_dbServices_")) return "mpi_db";
  if (k.startsWith("mpi_license_")) return "mpi_license";
  // Backup rows are hidden for now (backup will return priced by retention).
  // Returning null keeps them out of the panel instead of leaking into
  // "MPI — Fixed Fees" via the generic mpi_ prefix below.
  if (k.startsWith("mpi_backup")) return null;
  if (k.startsWith("mpi_")) return "mpi_fixed";
  return null;
}

export function PricingPanel({ currentUser, onRateCardChanged, t }) {
  const [rows, setRows] = useState([]);
  const [audit, setAudit] = useState([]);
  const [editingKey, setEditingKey] = useState(null);
  const [editVal, setEditVal] = useState("");
  const [showLog, setShowLog] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => { load(); }, []);
  const load = async () => {
    const [p, a] = await Promise.all([api.getProducts(), api.getAuditLog().catch(() => [])]);
    setRows(p || []);
    setAudit(a || []);
  };

  // Filter visible rows by role: pricing_admin sees only their assigned products
  const visibleRows = rows.filter((r) => {
    if (currentUser.role === "super_admin") return true;
    if (currentUser.role !== "pricing_admin") return false;
    const g = GROUPS.find((x) => x.id === matchGroup(r));
    if (!g || !g.product) return false;
    return (currentUser.assignedProducts || []).includes(g.product);
  });

  const save = async (row) => {
    const v = parseFloat(editVal);
    if (isNaN(v) || v < 0) { setErr("Invalid price"); return; }
    try {
      await api.updateProduct(row.rowKey, v);
      setEditingKey(null); setEditVal(""); setErr("");
      await load();
      onRateCardChanged?.();
    } catch (e) { setErr(e.message); }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.03em", margin: 0, color: t.text }}>Pricing Panel</h2>
          <p style={{ fontSize: 13, color: t.textSec, margin: "4px 0 0" }}>All prices in EUR, excl. opCo VAT</p>
        </div>
        <button onClick={() => setShowLog(!showLog)}
          style={{ padding: "8px 16px", borderRadius: 9, border: `1px solid ${t.inputBorder}`,
                   background: showLog ? "rgba(139,92,246,0.12)" : t.card,
                   color: showLog ? "#8B5CF6" : t.textSec, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
          📋 Audit Log {audit.length > 0 && `(${audit.length})`}
        </button>
      </div>

      {err && <div style={{ marginBottom: 12, padding: "10px 14px", borderRadius: 8, background: "rgba(255,60,60,0.08)", color: "#FF5555", fontSize: 12 }}>{err}</div>}

      {showLog && audit.length > 0 && (
        <Card t={t} style={{ marginBottom: 20, padding: 0, overflow: "hidden", border: "1px solid rgba(139,92,246,0.2)" }}>
          <div style={{ padding: "10px 18px", background: "rgba(139,92,246,0.08)", fontSize: 13, fontWeight: 700, color: t.text }}>Audit Log</div>
          {audit.map((e) => (
            <div key={e.id} style={{ padding: "10px 18px", borderTop: `1px solid ${t.divider}`, fontSize: 12, display: "flex", gap: 12 }}>
              <span style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, color: t.textMuted, minWidth: 140 }}>
                {new Date(e.timestamp).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}
              </span>
              <span style={{ fontWeight: 600, minWidth: 140, color: t.text }}>{e.userName}</span>
              <span style={{ color: t.textSec, flex: 1 }}>
                {e.itemKey}: €{Number(e.oldPrice).toFixed(2)} → <strong style={{ color: t.text }}>€{Number(e.newPrice).toFixed(2)}</strong>
              </span>
            </div>
          ))}
        </Card>
      )}

      {GROUPS.map((g) => {
        const groupRows = visibleRows.filter((r) => matchGroup(r) === g.id);
        if (groupRows.length === 0) return null;
        return (
          <Card t={t} key={g.id} style={{ marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: t.text, marginBottom: 12 }}>{g.title}</div>
            <div style={{ borderRadius: 10, overflow: "hidden", border: `1px solid ${t.cardBorder}` }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 160px 120px 70px", padding: "8px 14px", background: t.rowHover,
                            fontSize: 10, color: t.textSec, textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 700 }}>
                <span>Item</span><span>Unit</span><span>Price</span><span></span>
              </div>
              {groupRows.map((r) => {
                const editing = editingKey === r.rowKey;
                return (
                  <div key={r.rowKey} style={{ display: "grid", gridTemplateColumns: "1fr 160px 120px 70px",
                                               alignItems: "center", padding: "10px 14px", borderTop: `1px solid ${t.divider}` }}>
                    <span style={{ fontWeight: 600, fontSize: 13, color: t.text }}>{r.label}</span>
                    <span style={{ fontSize: 11, color: t.textSec }}>{r.unit}</span>
                    {editing ? (
                      <div style={{ display: "flex", gap: 4 }}>
                        <input value={editVal} autoFocus
                          onChange={(e) => setEditVal(e.target.value)}
                          onKeyDown={(e) => { if (e.key === "Enter") save(r); if (e.key === "Escape") { setEditingKey(null); setErr(""); } }}
                          style={{ width: 80, padding: "4px 8px", borderRadius: 6, background: t.input,
                                   border: "1px solid #00A0E1", color: t.text, fontSize: 12, fontFamily: "'DM Mono',monospace" }} />
                        <button onClick={() => save(r)}
                          style={{ padding: "3px 8px", borderRadius: 6, border: "none", background: "#00A0E1", color: "#fff",
                                   fontSize: 10, fontWeight: 700, cursor: "pointer" }}>✓</button>
                      </div>
                    ) : (
                      <span style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 13, color: "#00A0E1" }}>
                        €{Number(r.price).toFixed(2)}
                      </span>
                    )}
                    {!editing && (
                      <button onClick={() => { setEditingKey(r.rowKey); setEditVal(String(r.price)); }}
                        style={{ padding: "4px 10px", borderRadius: 6, border: `1px solid ${t.inputBorder}`,
                                 background: t.card, color: t.textSec, fontSize: 10, fontWeight: 600, cursor: "pointer" }}>Edit</button>
                    )}
                  </div>
                );
              })}
            </div>
          </Card>
        );
      })}
    </div>
  );
}
