import { useEffect, useState, useMemo } from "react";
import { Card, Badge } from "../components/UI.jsx";
import { api } from "../lib/api.js";
import { PRODUCTS, ROLES } from "../lib/constants.js";

export function IAM({ t }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [err, setErr] = useState("");
  const [editing, setEditing] = useState(null); // { mode: "add"|"edit", user }

  useEffect(() => { load(); }, []);
  const load = async () => {
    setLoading(true);
    try { setUsers(await api.getUsers()); }
    catch (e) { setErr(e.message); }
    finally { setLoading(false); }
  };

  const openAdd = () => setEditing({
    mode: "add",
    user: { name: "", email: "", upn: "", role: "user", assignedProducts: [] },
  });
  const openEdit = (u) => setEditing({
    mode: "edit",
    user: { ...u, assignedProducts: u.assignedProducts || [] },
  });

  const saveUser = async (form) => {
    setErr("");
    if (editing.mode === "add") await api.addUser(form);
    else await api.updateUser(form);
    setEditing(null);
    await load();
  };

  const updateRole = async (u, role) => {
    await api.updateUser({ ...u, role });
    await load();
  };
  const toggleProduct = async (u, pid) => {
    const a = u.assignedProducts || [];
    const next = a.includes(pid) ? a.filter((x) => x !== pid) : [...a, pid];
    await api.updateUser({ ...u, assignedProducts: next });
    await load();
  };
  const remove = async (u) => {
    if (!confirm(`Remove ${u.name}? They will be re-added automatically if they sign in again.`)) return;
    await api.removeUser(u.email);
    await load();
  };

  // Filtered + searched list
  const filtered = useMemo(() => {
    let list = users;
    if (roleFilter !== "all") list = list.filter((u) => u.role === roleFilter);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((u) =>
        (u.name || "").toLowerCase().includes(q) ||
        (u.email || "").toLowerCase().includes(q) ||
        (u.upn || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [users, search, roleFilter]);

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.03em", margin: 0, color: t.text }}>IAM Management</h2>
          <p style={{ fontSize: 13, color: t.textSec, margin: "4px 0 0" }}>
            All AXA users are auto-provisioned as "User" on first sign-in. Search and elevate roles as needed.
          </p>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <button onClick={openAdd}
            style={{ padding: "9px 20px", borderRadius: 10, border: "none", cursor: "pointer",
                     background: "linear-gradient(135deg, #00008F, #00A0E1)", color: "#fff",
                     fontWeight: 700, fontSize: 13 }}>
            + Add User
          </button>
          <button onClick={load} disabled={loading}
            style={{ padding: "9px 20px", borderRadius: 10, border: `1px solid ${t.inputBorder}`, cursor: "pointer",
                     background: t.card, color: t.textSec, fontWeight: 600, fontSize: 13,
                     display: "flex", alignItems: "center", gap: 6 }}>
            {loading ? "Refreshing…" : "↻ Refresh"}
          </button>
        </div>
      </div>

      {err && <div style={{ marginBottom: 12, padding: "10px 14px", borderRadius: 8, background: "rgba(255,60,60,0.08)", color: "#FF5555", fontSize: 12 }}>{err}</div>}

      {/* Role summary cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 20 }}>
        {Object.entries(ROLES).map(([k, r]) => {
          const cnt = users.filter((u) => u.role === k).length;
          return (
            <Card t={t} key={k} style={{ padding: 16, cursor: "pointer", border: roleFilter === k ? `1.5px solid ${r.color}60` : undefined }}
                  onClick={() => setRoleFilter(roleFilter === k ? "all" : k)}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <Badge color={r.color}>{r.label}</Badge>
                <span style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 22, color: r.color }}>{cnt}</span>
              </div>
              <div style={{ fontSize: 11, color: t.textSec, marginTop: 8 }}>{r.desc}</div>
            </Card>
          );
        })}
      </div>

      {/* Search bar */}
      <div style={{ display: "flex", gap: 10, marginBottom: 16, alignItems: "center" }}>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, email, or UPN…"
          style={{ flex: 1, padding: "11px 16px", borderRadius: 10, background: t.input, border: `1px solid ${t.inputBorder}`, color: t.text, fontSize: 14, boxSizing: "border-box" }}
        />
        {roleFilter !== "all" && (
          <button onClick={() => setRoleFilter("all")}
            style={{ padding: "9px 14px", borderRadius: 9, border: `1px solid ${t.inputBorder}`, background: t.card, color: t.textSec, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
            Clear filter: {ROLES[roleFilter].label} ✕
          </button>
        )}
        <span style={{ fontSize: 12, color: t.textSec, whiteSpace: "nowrap" }}>
          {filtered.length} of {users.length}
        </span>
      </div>

      {/* Users table */}
      <Card t={t} style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ display: "grid", gridTemplateColumns: "44px 1fr 1.2fr 1fr 130px 132px",
                      padding: "12px 20px", background: t.rowHover, fontSize: 10, color: t.textSec,
                      textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 700 }}>
          <span></span><span>Name</span><span>Email</span><span>UPN / GAD ID</span><span>Role</span><span></span>
        </div>

        {filtered.length === 0 && (
          <div style={{ padding: "32px 20px", textAlign: "center", color: t.textMuted, fontSize: 13 }}>
            {search || roleFilter !== "all" ? "No users match your search." : "No users yet."}
          </div>
        )}

        {filtered.map((u) => (
          <div key={u.email} style={{ borderTop: `1px solid ${t.divider}` }}>
            <div style={{ display: "grid", gridTemplateColumns: "44px 1fr 1.2fr 1fr 130px 132px", alignItems: "center", padding: "12px 20px" }}>
              <div style={{ width: 32, height: 32, borderRadius: 9, background: `${ROLES[u.role]?.color || "#888"}18`,
                            border: `1px solid ${ROLES[u.role]?.color || "#888"}25`, display: "flex", alignItems: "center",
                            justifyContent: "center", fontSize: 11, fontWeight: 700, color: ROLES[u.role]?.color || "#888" }}>
                {u.avatar}
              </div>
              <span style={{ fontWeight: 600, fontSize: 13, color: t.text }}>{u.name}</span>
              <span style={{ fontSize: 12, color: t.textSec }}>{u.email}</span>
              <span style={{ fontSize: 11, color: u.upn ? t.textSec : t.textMuted, fontStyle: u.upn ? "normal" : "italic" }}>
                {u.upn || "pending first sign-in"}
              </span>
              <select value={u.role} onChange={(e) => updateRole(u, e.target.value)}
                style={{ padding: "5px 10px", borderRadius: 7, background: t.input,
                         border: `1px solid ${t.inputBorder}`, color: ROLES[u.role]?.color || t.text,
                         fontSize: 12, fontWeight: 600, cursor: "pointer", width: "100%" }}>
                {Object.entries(ROLES).map(([k, r]) => (
                  <option key={k} value={k} style={{ background: t.selectBg, color: t.text }}>{r.label}</option>
                ))}
              </select>
              <div style={{ display: "flex", gap: 6, justifySelf: "end" }}>
                <button onClick={() => openEdit(u)}
                  style={{ padding: "5px 12px", borderRadius: 7, border: `1px solid ${t.inputBorder}`,
                           background: t.card, color: t.textSec, fontSize: 11, fontWeight: 600,
                           cursor: "pointer" }}>Edit</button>
                <button onClick={() => remove(u)}
                  style={{ padding: "5px 12px", borderRadius: 7, border: "1px solid rgba(255,60,60,0.2)",
                           background: "rgba(255,60,60,0.06)", color: "#FF5555", fontSize: 11, fontWeight: 600,
                           cursor: "pointer" }}>Remove</button>
              </div>
            </div>
            {u.role === "pricing_admin" && (
              <div style={{ padding: "0 20px 12px 64px" }}>
                <div style={{ fontSize: 10, color: t.textSec, marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>
                  Assigned Products
                </div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {PRODUCTS.map((p) => {
                    const on = (u.assignedProducts || []).includes(p.id);
                    return (
                      <button key={p.id} onClick={() => toggleProduct(u, p.id)}
                        style={{ padding: "5px 12px", borderRadius: 8, cursor: "pointer", fontSize: 11, fontWeight: 600,
                                 border: on ? `1.5px solid ${p.color}50` : `1.5px solid ${t.cardBorder}`,
                                 background: on ? `${p.color}15` : t.card, color: on ? p.color : t.textMuted }}>
                        {p.icon} {p.name}{on && " ✓"}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
            {u.role === "super_admin" && (
              <div style={{ padding: "0 20px 10px 64px" }}>
                <span style={{ fontSize: 10, color: t.textMuted, fontStyle: "italic" }}>All products</span>
              </div>
            )}
          </div>
        ))}
      </Card>

      {editing && (
        <UserModal
          t={t}
          mode={editing.mode}
          initial={editing.user}
          onCancel={() => setEditing(null)}
          onSave={saveUser}
        />
      )}
    </div>
  );
}

function UserModal({ t, mode, initial, onCancel, onSave }) {
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const isAdd = mode === "add";
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  const inputStyle = {
    width: "100%", padding: "10px 12px", borderRadius: 9, background: t.input,
    border: `1px solid ${t.inputBorder}`, color: t.text, fontSize: 13,
    boxSizing: "border-box", outline: "none",
  };
  const labelStyle = {
    fontSize: 11, fontWeight: 700, color: t.textSec, marginBottom: 6,
    textTransform: "uppercase", letterSpacing: "0.06em",
  };

  const submit = async () => {
    setError("");
    if (!form.name?.trim()) return setError("Name is required.");
    if (!form.email?.trim()) return setError("Email is required.");
    setSaving(true);
    try {
      await onSave({
        ...form,
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        upn: (form.upn || "").trim().toLowerCase(),
        assignedProducts: form.role === "pricing_admin" ? (form.assignedProducts || []) : [],
      });
    } catch (e) {
      setError(e.message || "Save failed.");
      setSaving(false);
    }
  };

  return (
    <div
      onClick={onCancel}
      style={{
        position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.55)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 460, maxWidth: "100%", maxHeight: "90vh", overflowY: "auto",
          background: t.selectBg, border: `1px solid ${t.cardBorder}`, borderRadius: 16,
          boxShadow: "0 24px 70px rgba(0,0,0,0.45)", fontFamily: "'DM Sans',sans-serif",
        }}
      >
        <div style={{ padding: "16px 20px", background: "linear-gradient(135deg, #00008F, #00A0E1)", color: "#fff" }}>
          <div style={{ fontWeight: 800, fontSize: 15 }}>{isAdd ? "Add User" : "Edit User"}</div>
          <div style={{ fontSize: 11, opacity: 0.85, marginTop: 2 }}>
            {isAdd ? "Pre-provision a user and set their role up front." : "Update the display name, role, or product access."}
          </div>
        </div>

        <div style={{ padding: 20, display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <div style={labelStyle}>Display Name</div>
            <input value={form.name || ""} onChange={(e) => set({ name: e.target.value })}
              placeholder="e.g. Minanatha Sivan" style={inputStyle} />
          </div>

          <div>
            <div style={labelStyle}>Email</div>
            <input value={form.email || ""} onChange={(e) => set({ email: e.target.value })}
              placeholder="name@axa.com" disabled={!isAdd}
              style={{ ...inputStyle, opacity: isAdd ? 1 : 0.6, cursor: isAdd ? "text" : "not-allowed" }} />
            {!isAdd && (
              <div style={{ fontSize: 10, color: t.textMuted, marginTop: 4 }}>
                Email is the record key and cannot be changed.
              </div>
            )}
          </div>

          <div>
            <div style={labelStyle}>UPN / GAD ID <span style={{ textTransform: "none", fontWeight: 500 }}>(optional)</span></div>
            <input value={form.upn || ""} onChange={(e) => set({ upn: e.target.value })}
              placeholder="e.g. z179gt@login.axa" style={inputStyle} />
            <div style={{ fontSize: 10, color: t.textMuted, marginTop: 4 }}>
              Leave blank to fill in automatically on their first sign-in.
            </div>
          </div>

          <div>
            <div style={labelStyle}>Role</div>
            <select value={form.role} onChange={(e) => set({ role: e.target.value })}
              style={{ ...inputStyle, cursor: "pointer" }}>
              {Object.entries(ROLES).map(([k, r]) => (
                <option key={k} value={k} style={{ background: t.selectBg, color: t.text }}>{r.label}</option>
              ))}
            </select>
            <div style={{ fontSize: 10, color: t.textMuted, marginTop: 4 }}>{ROLES[form.role]?.desc}</div>
          </div>

          {form.role === "pricing_admin" && (
            <div>
              <div style={labelStyle}>Assigned Products</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {PRODUCTS.map((p) => {
                  const on = (form.assignedProducts || []).includes(p.id);
                  return (
                    <button key={p.id}
                      onClick={() => set({
                        assignedProducts: on
                          ? (form.assignedProducts || []).filter((x) => x !== p.id)
                          : [...(form.assignedProducts || []), p.id],
                      })}
                      style={{ padding: "5px 12px", borderRadius: 8, cursor: "pointer", fontSize: 11, fontWeight: 600,
                               border: on ? `1.5px solid ${p.color}50` : `1.5px solid ${t.cardBorder}`,
                               background: on ? `${p.color}15` : "transparent", color: on ? p.color : t.textMuted }}>
                      {p.icon} {p.name}{on && " ✓"}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {error && (
            <div style={{ padding: "9px 12px", borderRadius: 8, background: "rgba(255,60,60,0.08)", color: "#FF5555", fontSize: 12 }}>
              {error}
            </div>
          )}

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 4 }}>
            <button onClick={onCancel} disabled={saving}
              style={{ padding: "9px 18px", borderRadius: 9, border: `1px solid ${t.inputBorder}`,
                       background: "transparent", color: t.textSec, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
              Cancel
            </button>
            <button onClick={submit} disabled={saving}
              style={{ padding: "9px 20px", borderRadius: 9, border: "none",
                       background: saving ? t.inputBorder : "linear-gradient(135deg, #00008F, #00A0E1)",
                       color: "#fff", fontSize: 13, fontWeight: 700, cursor: saving ? "not-allowed" : "pointer" }}>
              {saving ? "Saving…" : isAdd ? "Add User" : "Save Changes"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}