import { useEffect, useState } from "react";
import { Card, Badge, ConfirmDialog } from "../components/UI.jsx";
import { MpiVmForm } from "../components/MpiVmForm.jsx";
import { PRODUCTS } from "../lib/constants.js";
import {
  calcMpiItem, calcNasItem, calcPodItem, calcTerraformItem,
  calcEstimateTotal,
} from "../lib/calc.js";
import { fmt, fmtFull } from "../lib/currency.js";
import { exportEstimateExcel } from "../lib/excelExport.js";
import { api } from "../lib/api.js";
import { RightSizer } from "../components/RightSizer.jsx";

export function Estimator({ rateCard, currentUser, display, fxRate, t }) {
  const [projectName, setProjectName] = useState("");
  const [projectNameTouched, setProjectNameTouched] = useState(false);
  const [sections, setSections] = useState({}); // { productId: [item, item, ...] }
  const [editingId, setEditingId] = useState(null);
  const [savedEstimates, setSavedEstimates] = useState([]);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null); // estimate pending delete
  const [deleting, setDeleting] = useState(false);

  const projectNameInvalid = projectNameTouched && !projectName.trim();

  useEffect(() => { api.getEstimates().then(setSavedEstimates).catch(() => {}); }, []);

  // --- mutations ------------------------------------------------------------
  const addItem = (pid) => {
    const blank = pid === "mpi"
      ? { id: crypto.randomUUID(), productId: pid, config: {}, vmCount: 1 }
      : { id: crypto.randomUUID(), productId: pid, qty: 1 };
    setSections((s) => ({ ...s, [pid]: [...(s[pid] || []), blank] }));
  };
  const updateItem = (pid, id, patch) =>
    setSections((s) => ({ ...s, [pid]: s[pid].map((it) => (it.id === id ? { ...it, ...patch } : it)) }));
  const removeItem = (pid, id) =>
    setSections((s) => {
      const list = (s[pid] || []).filter((it) => it.id !== id);
      const next = { ...s };
      if (list.length) next[pid] = list; else delete next[pid];
      return next;
    });
  const duplicateItem = (pid, item) =>
    setSections((s) => ({ ...s, [pid]: [...s[pid], { ...JSON.parse(JSON.stringify(item)), id: crypto.randomUUID() }] }));

  // --- compute every item -------------------------------------------------
  const allItems = [];
  for (const p of PRODUCTS) {
    const list = sections[p.id] || [];
    for (const raw of list) {
      let calc;
      if (p.id === "mpi")       calc = calcMpiItem(rateCard, { ...raw.config, vmCount: raw.vmCount });
      else if (p.id === "nas")  calc = calcNasItem(rateCard, raw.qty);
      else if (p.id === "pod")  calc = calcPodItem(rateCard, raw.qty);
      else                      calc = calcTerraformItem(rateCard, raw.qty);

      allItems.push({
        id: raw.id,
        productId: p.id,
        productName: p.name,
        icon: p.icon,
        color: p.color,
        ...(p.id === "mpi" ? { config: raw.config, vmCount: raw.vmCount } : { qty: raw.qty, [p.id === "nas" ? "tb" : p.id === "pod" ? "pods" : "workspaces"]: raw.qty }),
        ...calc,
      });
    }
  }
  const { totalMonthlyEur, totalAnnualEur } = calcEstimateTotal(allItems);
  const hasItems = allItems.length > 0;

  // --- persistence --------------------------------------------------------
  const doSave = async () => {
    if (!projectName.trim() || !hasItems) return;
    setSaving(true);
    const payload = {
      id: editingId || crypto.randomUUID(),
      projectName: projectName.trim(),
      items: allItems,
      totalMonthlyEur, totalAnnualEur,
      updatedAt: new Date().toISOString(),
    };
    try {
      if (editingId) {
        await api.updateEstimate(payload);
      } else {
        payload.createdAt = payload.updatedAt;
        await api.saveEstimate(payload);
      }
      setSavedEstimates(await api.getEstimates());
      setProjectName(""); setSections({}); setEditingId(null); setProjectNameTouched(false);
    } finally { setSaving(false); }
  };

  const loadEstimate = (est) => {
    setEditingId(est.id);
    setProjectName(est.projectName);
    setProjectNameTouched(false);
    const next = {};
    for (const it of est.items) {
      (next[it.productId] = next[it.productId] || []).push(
        it.productId === "mpi"
          ? { id: crypto.randomUUID(), productId: "mpi", config: it.config || {}, vmCount: it.vmCount || 1 }
          : { id: crypto.randomUUID(), productId: it.productId, qty: it.qty || it.tb || it.pods || it.workspaces || 1 }
      );
    }
    setSections(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteEstimate(deleteTarget.id);
      setSavedEstimates(await api.getEstimates());
      setDeleteTarget(null);
    } finally {
      setDeleting(false);
    }
  };

  const doExport = (est) => exportEstimateExcel(est, display, fxRate);

  // --- render -------------------------------------------------------------
  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.03em", margin: "0 0 4px", color: t.text }}>Budget Estimator</h2>
      <p style={{ fontSize: 13, color: t.textSec, margin: "0 0 20px" }}>
        Configure products to estimate project costs — budget use only, excl. opCo VAT.
      </p>

      <Card t={t} style={{ marginBottom: 20, padding: "16px 20px" }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: t.textSec, marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.08em" }}>
          Project Name <span style={{ color: "#E34850" }} aria-hidden="true">*</span>
        </div>
        <input value={projectName} onChange={(e) => setProjectName(e.target.value)}
               onBlur={() => setProjectNameTouched(true)}
               placeholder="e.g. Project Alpha"
               aria-required="true"
               aria-invalid={projectNameInvalid}
               style={{ width: "100%", padding: "10px 14px", borderRadius: 10, background: t.input,
                        border: `1px solid ${projectNameInvalid ? "#E34850" : t.inputBorder}`,
                        color: t.text, fontSize: 14, boxSizing: "border-box" }} />
        <div style={{ fontSize: 12, color: projectNameInvalid ? "#E34850" : t.textMuted, marginTop: 6 }}>
          {projectNameInvalid ? "Project name is required." : "Required to save your estimate."}
        </div>
      </Card>

      {/* Product tiles */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: t.textSec, marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.1em" }}>
          Select Products
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 15 }}>
          {PRODUCTS.filter((p) => !p.hidden).map((p) => {
            const cnt = (sections[p.id] || []).length;
            return (
              <button key={p.id} onClick={() => addItem(p.id)}
                style={{
                  padding: "16px 12px", borderRadius: 14, cursor: "pointer",
                  background: cnt > 0 ? `linear-gradient(135deg, ${p.color}18, ${p.color}06)` : t.card,
                  border: cnt > 0 ? `2px solid ${p.color}50` : `2px solid ${t.cardBorder}`,
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 6, position: "relative",
                  boxShadow: t.shadow,
                }}>
                {cnt > 0 && (
                  <div style={{ position: "absolute", top: 6, right: 8, background: p.color, color: "#fff",
                                fontSize: 10, fontWeight: 700, width: 18, height: 18, borderRadius: "50%",
                                display: "flex", alignItems: "center", justifyContent: "center" }}>{cnt}</div>
                )}
                <div style={{ width: 60, height: 50, borderRadius: 12, background: `${p.color}12`,
                              border: `1px solid ${p.color}20`, display: "flex", alignItems: "center",
                              justifyContent: "center", fontSize: 20 }}>{p.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 13, color: cnt > 0 ? t.text : t.textSec, textAlign: "center" }}>{p.name}</div>
                <div style={{ fontSize: 10, color: p.color, fontWeight: 600 }}>+ {cnt > 0 ? "Add another" : "Add"}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* MPI VM size recommendation assistant (floating launcher + panel) */}
      <RightSizer user={currentUser} t={t} />

      {/* Per-product sections */}
      {PRODUCTS.filter((p) => (sections[p.id] || []).length > 0).map((p) => {
        const list = sections[p.id];
        return (
          <Card t={t} key={p.id} style={{ marginBottom: 16, padding: 0, overflow: "hidden", border: `1.5px solid ${p.color}30` }}>
            <div style={{ padding: "12px 20px", background: p.color, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 18 }}>{p.icon}</span>
                <span style={{ fontWeight: 700, fontSize: 15, color: "#fff" }}>{p.name}</span>
                <span style={{ fontSize: 11, color: "rgba(255,255,255,0.7)" }}>— {p.fullName}</span>
              </div>
              <Badge color="#fff" small>{list.length} item{list.length > 1 ? "s" : ""}</Badge>
            </div>

            {list.map((item, idx) => {
              const calc = allItems.find((a) => a.id === item.id);
              return (
                <div key={item.id} style={{ padding: "16px 20px", borderTop: idx > 0 ? `1px solid ${t.divider}` : "none" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                    <span style={{ fontSize: 12, fontWeight: 600, color: t.textSec }}>Item {idx + 1}</span>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => duplicateItem(p.id, item)}
                        style={{ padding: "4px 10px", borderRadius: 7, border: `1px solid ${p.color}30`,
                                 background: `${p.color}10`, color: p.color, fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                        + Duplicate
                      </button>
                      <button onClick={() => removeItem(p.id, item.id)}
                        style={{ padding: "4px 10px", borderRadius: 7, border: "1px solid rgba(255,60,60,0.2)",
                                 background: "rgba(255,60,60,0.06)", color: "#FF5555", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
                        Remove
                      </button>
                    </div>
                  </div>

                  {p.id === "mpi" ? (
                    <>
                      <MpiVmForm config={item.config} t={t}
                        onChange={(cfg) => updateItem(p.id, item.id, { config: cfg })} />
                      <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: t.textSec }}>Number of VMs</div>
                        <input type="number" min={1} value={item.vmCount || 1}
                          onChange={(e) => updateItem(p.id, item.id, { vmCount: Math.max(1, parseInt(e.target.value) || 1) })}
                          style={{ width: 80, padding: "6px 10px", borderRadius: 8, background: t.input,
                                   border: `1px solid ${t.inputBorder}`, color: t.text, fontSize: 13,
                                   fontFamily: "'DM Mono',monospace", textAlign: "center" }} />
                      </div>
                      {calc && calc.breakdown && calc.breakdown.length > 0 && (
                        <div style={{ marginTop: 14, padding: "14px 16px", borderRadius: 10,
                                      background: "rgba(0,160,225,0.04)", border: "1px solid rgba(0,160,225,0.12)" }}>
                          <div style={{ fontSize: 11, fontWeight: 700, color: t.textSec, textTransform: "uppercase",
                                        letterSpacing: "0.08em", marginBottom: 10 }}>
                            Breakdown ({item.vmCount || 1} VM{(item.vmCount || 1) > 1 ? "s" : ""})
                          </div>
                          {calc.breakdown.map((b) => (
                            <div key={b.key} style={{ display: "flex", justifyContent: "space-between",
                                                      padding: "4px 0", borderBottom: `1px solid ${t.divider}` }}>
                              <span style={{ fontSize: 12, color: t.textSec }}>{b.label}</span>
                              <span style={{ fontFamily: "'DM Mono',monospace", fontSize: 12, fontWeight: 600, color: "#00A0E1" }}>
                                {fmtFull(b.monthly, display, fxRate)}/mo
                              </span>
                            </div>
                          ))}
                          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10,
                                        paddingTop: 10, borderTop: "1px solid rgba(0,160,225,0.2)" }}>
                            <span style={{ fontSize: 13, fontWeight: 700, color: t.textSec }}>Item Total</span>
                            <div style={{ textAlign: "right" }}>
                              <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 18, color: "#00A0E1" }}>
                                {fmtFull(calc.itemMonthlyEur, display, fxRate)}/mo
                              </div>
                              <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 600, fontSize: 13, color: t.textSec }}>
                                {fmtFull(calc.itemAnnualEur, display, fxRate)}/yr
                              </div>
                            </div>
                          </div>
                          {calc.warnings?.map((w, i) => (
                            <div key={i} style={{ marginTop: 8, fontSize: 11, color: "#E5A800" }}>⚠ {w}</div>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16 }}>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: t.textSec, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>
                          Quantity ({p.unit})
                        </div>
                        <input type="number" min={1} value={item.qty || 1}
                          onChange={(e) => updateItem(p.id, item.id, { qty: Math.max(1, parseInt(e.target.value) || 1) })}
                          style={{ width: 100, padding: "8px 12px", borderRadius: 8, background: t.input,
                                   border: `1px solid ${t.inputBorder}`, color: t.text, fontSize: 14, fontWeight: 600,
                                   fontFamily: "'DM Mono',monospace", textAlign: "center" }} />
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 20, color: p.color }}>
                          {fmtFull(calc?.itemMonthlyEur || 0, display, fxRate)}/mo
                        </div>
                        <div style={{ fontSize: 11, color: t.textSec }}>
                          {fmtFull(calc?.itemAnnualEur || 0, display, fxRate)}/yr
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            {/* Add another item button at bottom of product section */}
            <div style={{ padding: "12px 20px", borderTop: `1px solid ${t.divider}` }}>
              <button onClick={() => addItem(p.id)} style={{
                width: "100%", padding: "10px", borderRadius: 10, cursor: "pointer",
                border: `1.5px dashed ${p.color}40`, background: "transparent",
                color: p.color, fontSize: 13, fontWeight: 700,
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}>+ Add Another {p.name}</button>
            </div>
          </Card>
        );
      })}

      {/* Totals & save */}
      {hasItems && (
        <Card t={t} style={{ padding: 0, overflow: "hidden", marginBottom: 20 }}>
          <div style={{ padding: "16px 20px", background: "rgba(0,160,225,0.06)",
                        borderBottom: `1px solid ${t.divider}`, display: "flex",
                        justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: t.text }}>
              {projectName.trim() || "Untitled"} — Grand Total
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 24, color: "#00A0E1" }}>
                {fmt(totalMonthlyEur, display, fxRate)}/mo
              </div>
              <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 600, fontSize: 14, color: t.textSec }}>
                {fmt(totalAnnualEur, display, fxRate)}/yr
              </div>
            </div>
          </div>
          <div style={{ padding: "14px 20px", display: "flex", gap: 10, borderTop: `1px solid ${t.divider}` }}>
            <button onClick={doSave} disabled={!projectName.trim() || saving}
              title={!projectName.trim() ? "Enter a project name to save" : ""}
              style={{ flex: 1, padding: 11, borderRadius: 10, fontWeight: 700, fontSize: 13,
                       cursor: !projectName.trim() ? "not-allowed" : "pointer", border: "none",
                       background: projectName.trim() ? "linear-gradient(135deg, #00008F, #00A0E1)" : t.input,
                       color: projectName.trim() ? "#fff" : t.textMuted }}>
              {saving ? "Saving…" : editingId ? "💾 Update Estimate" : "💾 Save Estimate"}
            </button>
            <button onClick={() => doExport({
                projectName: projectName.trim() || "Untitled",
                items: allItems,
              })}
              style={{ flex: 1, padding: 11, borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: "pointer",
                       border: "1px solid rgba(0,201,167,0.3)", background: "rgba(0,201,167,0.08)", color: "#00C9A7" }}>
              📊 Export Excel
            </button>
          </div>
          <div style={{ padding: "8px 20px 12px", fontSize: 10, color: t.textMuted, textAlign: "center" }}>
            ⚠ Budget estimation only — prices excl. opCo VAT.
          </div>
        </Card>
      )}

      {/* Saved estimates */}
      {savedEstimates.length > 0 && (
        <div>
          <div style={{ fontSize: 11, fontWeight: 600, color: t.textSec, marginBottom: 12,
                        textTransform: "uppercase", letterSpacing: "0.1em" }}>
            {currentUser.role === "super_admin" ? "All Estimates" : "My Estimates"}
          </div>
          {savedEstimates.map((se) => (
            <Card t={t} key={se.id} style={{ padding: "14px 18px", marginBottom: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: t.text }}>{se.projectName}</div>
                  <div style={{ fontSize: 11, color: t.textSec, marginTop: 2 }}>
                    {se.items.length} items · {new Date(se.createdAt).toLocaleDateString()}
                    {currentUser.role === "super_admin" && se.ownerName && ` · by ${se.ownerName}`}
                  </div>
                </div>
                <div style={{ fontFamily: "'DM Mono',monospace", fontWeight: 700, fontSize: 16, color: "#00A0E1" }}>
                  {fmt(se.totalMonthlyEur || 0, display, fxRate)}/mo
                </div>
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button onClick={() => loadEstimate(se)}
                  style={{ padding: "6px 14px", borderRadius: 8, border: "1px solid rgba(0,160,225,0.3)",
                           background: "rgba(0,160,225,0.08)", color: "#00A0E1", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
                  ✏ Edit
                </button>
                <button onClick={() => doExport(se)}
                  style={{ padding: "6px 14px", borderRadius: 8, border: "1px solid rgba(0,201,167,0.3)",
                           background: "rgba(0,201,167,0.08)", color: "#00C9A7", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
                  📊 Export
                </button>
                <button onClick={() => setDeleteTarget(se)}
                  style={{ padding: "6px 14px", borderRadius: 8, border: "1px solid rgba(255,60,60,0.2)",
                           background: "rgba(255,60,60,0.06)", color: "#FF5555", fontSize: 11, fontWeight: 600, cursor: "pointer" }}>
                  🗑 Delete
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete this estimate?"
        message={deleteTarget
          ? `"${deleteTarget.projectName}" will be permanently removed. This action cannot be undone.`
          : ""}
        confirmLabel="Delete"
        cancelLabel="Cancel"
        danger
        busy={deleting}
        onConfirm={confirmDelete}
        onCancel={() => !deleting && setDeleteTarget(null)}
        t={t}
      />
    </div>
  );
}