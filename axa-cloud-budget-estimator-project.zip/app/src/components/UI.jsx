import { useState, useRef, useEffect } from "react";

/* ------------------------------------------------------------------ */
/*  Card                                                              */
/* ------------------------------------------------------------------ */
export function Card({ children, style = {}, t, ...p }) {
  return (
    <div style={{
      background: t?.card || "rgba(255,255,255,0.025)",
      border: `1px solid ${t?.cardBorder || "rgba(255,255,255,0.06)"}`,
      borderRadius: 16, padding: 22, boxShadow: t?.shadow || "none", ...style,
    }} {...p}>{children}</div>
  );
}

/* ------------------------------------------------------------------ */
/*  Badge                                                             */
/* ------------------------------------------------------------------ */
export function Badge({ children, color, small }) {
  return (
    <span style={{
      padding: small ? "2px 8px" : "4px 12px", borderRadius: 6,
      background: `${color}18`, border: `1px solid ${color}30`,
      color, fontSize: small ? 10 : 11, fontWeight: 600, whiteSpace: "nowrap",
    }}>{children}</span>
  );
}

/* ------------------------------------------------------------------ */
/*  Standard select (non-searchable)                                  */
/* ------------------------------------------------------------------ */
export function Sel({ label, value, onChange, options, placeholder, disabled, t }) {
  return (
    <div style={{ flex: 1, minWidth: 160 }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: t?.textSec, marginBottom: 6 }}>{label}</div>
      <select
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        style={{
          width: "100%", padding: "10px 14px", borderRadius: 10,
          background: t?.input, border: `1px solid ${t?.inputBorder}`,
          color: value ? t?.text : t?.textMuted, fontSize: 13,
          cursor: disabled ? "not-allowed" : "pointer",
          boxSizing: "border-box", opacity: disabled ? 0.5 : 1,
        }}
      >
        <option value="" style={{ background: t?.selectBg }}>{placeholder || `Select ${label}`}</option>
        {(options || []).map((o) => {
          const v = typeof o === "string" ? o : o.value;
          const l = typeof o === "string" ? o : o.label;
          return <option key={v} value={v} style={{ background: t?.selectBg, color: t?.text }}>{l}</option>;
        })}
      </select>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Searchable select — type to filter, click or arrow-key to select  */
/* ------------------------------------------------------------------ */
export function SearchableSel({ label, value, onChange, options, placeholder, disabled, t }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [highlighted, setHighlighted] = useState(-1);
  const wrapRef = useRef(null);
  const inputRef = useRef(null);
  const listRef = useRef(null);

  // Normalize options to { value, label }
  const normalized = (options || []).map((o) =>
    typeof o === "string" ? { value: o, label: o } : o
  );

  // Current display text
  const selectedOption = normalized.find((o) => o.value === value);
  const displayText = selectedOption ? selectedOption.label : "";

  // Filtered list based on search input
  const filtered = search
    ? normalized.filter((o) => o.label.toLowerCase().includes(search.toLowerCase()))
    : normalized;

  // Close dropdown when clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        setOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Scroll highlighted item into view
  useEffect(() => {
    if (listRef.current && highlighted >= 0) {
      const items = listRef.current.children;
      if (items[highlighted]) items[highlighted].scrollIntoView({ block: "nearest" });
    }
  }, [highlighted]);

  const handleSelect = (val) => {
    onChange(val);
    setOpen(false);
    setSearch("");
    setHighlighted(-1);
  };

  const handleKeyDown = (e) => {
    if (!open && (e.key === "ArrowDown" || e.key === "Enter")) {
      setOpen(true);
      e.preventDefault();
      return;
    }
    if (e.key === "ArrowDown") {
      setHighlighted((p) => Math.min(p + 1, filtered.length - 1));
      e.preventDefault();
    } else if (e.key === "ArrowUp") {
      setHighlighted((p) => Math.max(p - 1, 0));
      e.preventDefault();
    } else if (e.key === "Enter" && highlighted >= 0 && filtered[highlighted]) {
      handleSelect(filtered[highlighted].value);
      e.preventDefault();
    } else if (e.key === "Escape") {
      setOpen(false);
      setSearch("");
    }
  };

  return (
    <div ref={wrapRef} style={{ flex: 1, minWidth: 200, position: "relative" }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: t?.textSec, marginBottom: 6 }}>{label}</div>
      <input
        ref={inputRef}
        type="text"
        value={open ? search : displayText}
        placeholder={disabled ? (placeholder || `Select ${label}`) : (placeholder || `Type to search ${label}…`)}
        disabled={disabled}
        onFocus={() => { setOpen(true); setSearch(""); setHighlighted(-1); }}
        onChange={(e) => { setSearch(e.target.value); setOpen(true); setHighlighted(0); }}
        onKeyDown={handleKeyDown}
        style={{
          width: "100%", padding: "10px 14px", borderRadius: 10,
          background: t?.input, border: `1px solid ${open ? "#00A0E1" : t?.inputBorder}`,
          color: t?.text, fontSize: 13,
          cursor: disabled ? "not-allowed" : "text",
          boxSizing: "border-box", opacity: disabled ? 0.5 : 1,
          outline: "none",
        }}
      />
      {/* Dropdown arrow */}
      <span style={{
        position: "absolute", right: 12, top: 32, fontSize: 10,
        color: t?.textMuted, pointerEvents: "none",
      }}>▼</span>

      {/* Dropdown list */}
      {open && !disabled && filtered.length > 0 && (
        <div ref={listRef} style={{
          position: "absolute", top: "100%", left: 0, right: 0,
          maxHeight: 240, overflowY: "auto", zIndex: 100,
          background: t?.selectBg || "#0D1220",
          border: `1px solid ${t?.inputBorder}`, borderRadius: 10,
          marginTop: 4, boxShadow: "0 12px 40px rgba(0,0,0,0.25)",
        }}>
          {filtered.map((o, i) => (
            <div
              key={o.value}
              onMouseDown={(e) => { e.preventDefault(); handleSelect(o.value); }}
              onMouseEnter={() => setHighlighted(i)}
              style={{
                padding: "9px 14px", fontSize: 12, cursor: "pointer",
                background: i === highlighted ? "rgba(0,160,225,0.12)" : "transparent",
                color: o.value === value ? "#00A0E1" : t?.text,
                fontWeight: o.value === value ? 700 : 400,
                borderBottom: `1px solid ${t?.divider || "rgba(255,255,255,0.04)"}`,
              }}
            >
              {o.label}
            </div>
          ))}
        </div>
      )}
      {open && !disabled && filtered.length === 0 && search && (
        <div style={{
          position: "absolute", top: "100%", left: 0, right: 0,
          padding: "12px 14px", fontSize: 12, color: t?.textMuted,
          background: t?.selectBg || "#0D1220",
          border: `1px solid ${t?.inputBorder}`, borderRadius: 10, marginTop: 4,
        }}>
          No matches for "{search}"
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Logo — clean cloud with ascending bar chart inside                */
/* ------------------------------------------------------------------ */
export function CloudLogo() {
  return (
    <svg viewBox="0 0 120 120" width="48" height="48" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="bg1" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#1a1040"/>
          <stop offset="100%" stop-color="#0a0820"/>
        </radialGradient>
        <linearGradient id="ring1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#7b5ea7"/>
          <stop offset="50%" stop-color="#e06098"/>
          <stop offset="100%" stop-color="#6a7fd8"/>
        </linearGradient>
        <linearGradient id="cloud1" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#8b7bc8" stop-opacity="0.3"/>
          <stop offset="100%" stop-color="#4a3a80" stop-opacity="0.15"/>
        </linearGradient>
        <linearGradient id="bar1" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stop-color="#e060a0"/>
          <stop offset="100%" stop-color="#8090e0"/>
        </linearGradient>
        <path
          id="cloudShape"
          d="M82 62
            a10 10 0 0 0 -9.5 -10
            A13 13 0 0 0 48 55
            c-5 0 -9 4 -9 9
            s4 9 9 9
            h31
            a8 8 0 0 0 3 -16z"
        />
        <clipPath id="cloudClip" clipPathUnits="userSpaceOnUse">
          <use href="#cloudShape"/>
        </clipPath>
      </defs>
      <circle cx="60" cy="60" r="55" fill="url(#bg1)"/>
      <circle
        cx="60" cy="60" r="55"
        fill="none"
        stroke="url(#ring1)"
        stroke-width="5"
        opacity="0.95"
      />
      <circle
        cx="60" cy="60" r="48"
        fill="none"
        stroke="url(#ring1)"
        stroke-width="5"
        opacity="0.6"
      />
      <g transform="translate(60 60) scale(1.4) translate(-62 -60)">
        <g clip-path="url(#cloudClip)">
          <rect x="46" y="59" width="6" height="10" rx="2" fill="url(#bar1)"/>
          <rect x="57" y="51" width="6" height="18" rx="2" fill="url(#bar1)"/>
          <rect x="68" y="43" width="6" height="26" rx="2" fill="url(#bar1)"/>
        </g>
        <use
          href="#cloudShape"
          fill="url(#cloud1)"
          stroke="url(#ring1)"
          stroke-width="7"
          vector-effect="non-scaling-stroke"
          opacity="0.65"
        />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  ConfirmDialog — reusable themed confirmation modal                */
/* ------------------------------------------------------------------ */
export function ConfirmDialog({
  open,
  title = "Are you sure?",
  message,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  danger = false,
  busy = false,
  onConfirm,
  onCancel,
  t,
}) {
  // ESC to cancel
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape" && !busy) onCancel?.();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, busy, onCancel]);

  if (!open) return null;

  const confirmBg = danger
    ? "linear-gradient(135deg, #D93025, #FF5555)"
    : "linear-gradient(135deg, #00008F, #00A0E1)";

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-dialog-title"
      onClick={(e) => {
        // click on backdrop cancels (but not on the card itself)
        if (e.target === e.currentTarget && !busy) onCancel?.();
      }}
      style={{
        position: "fixed", inset: 0, zIndex: 9999,
        background: "rgba(0,0,0,0.65)", backdropFilter: "blur(8px)",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'DM Sans',sans-serif",
      }}
    >
      <div style={{
        background: t?.card || "#15171C",
        border: `1px solid ${t?.cardBorder || "rgba(255,255,255,0.06)"}`,
        borderRadius: 20,
        padding: "32px 36px",
        maxWidth: 440, width: "90%", textAlign: "center",
        boxShadow: "0 24px 80px rgba(0,0,0,0.35)",
      }}>
        <div style={{ fontSize: 36, marginBottom: 10 }}>{danger ? "⚠️" : "❓"}</div>
        <h2 id="confirm-dialog-title" style={{
          margin: "0 0 10px", fontSize: 18, fontWeight: 800, color: t?.text,
        }}>
          {title}
        </h2>
        {message && (
          <p style={{ fontSize: 14, lineHeight: 1.6, color: t?.textSec, margin: "0 0 24px" }}>
            {message}
          </p>
        )}
        <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
          <button
            onClick={onCancel}
            disabled={busy}
            style={{
              padding: "10px 24px", borderRadius: 10, cursor: busy ? "not-allowed" : "pointer",
              background: "transparent", color: t?.text,
              border: `1px solid ${t?.cardBorder || "rgba(255,255,255,0.15)"}`,
              fontSize: 13, fontWeight: 600,
              opacity: busy ? 0.5 : 1,
            }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            disabled={busy}
            style={{
              padding: "10px 24px", borderRadius: 10, border: "none",
              cursor: busy ? "not-allowed" : "pointer",
              background: confirmBg, color: "#fff",
              fontSize: 13, fontWeight: 700,
              opacity: busy ? 0.7 : 1,
            }}
          >
            {busy ? "Working…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}