import { useEffect, useMemo, useState } from "react";
import { Sel, SearchableSel } from "./UI.jsx";
import {
  APPROVED_REGIONS,
  AZURE_OS_OPTIONS,
  AWS_OS_OPTIONS,
  AZURE_DISK_TYPES,
  AWS_DISK_TYPES,
  DISK_SIZES_GB,
  PROVIDERS,
} from "../lib/constants.js";
import { api } from "../lib/api.js";

export function MpiVmForm({ config = {}, onChange, t }) {
  const [azureSkus, setAzureSkus] = useState([]);
  const [awsSkus, setAwsSkus] = useState([]);
  const [loading, setLoading] = useState(false);

  const osOptions = config.provider === "AWS" ? AWS_OS_OPTIONS : AZURE_OS_OPTIONS;

  // Fetch Azure SKUs from cache via Function App.
  // NOTE: fetch the FULL region list (no family filter) and narrow by family
  // client-side. Filtering server-side by config.vmFamily used to collapse the
  // SKU list to the selected family, which in turn collapsed the VM Family
  // dropdown (it is derived from these SKUs) so the choice could not be changed.
  useEffect(() => {
    if (config.provider === "Azure" && config.region) {
      setLoading(true);
      api.getAzurePrices(config.region, "")
        .then((list) => setAzureSkus(list || []))
        .catch(() => setAzureSkus([]))
        .finally(() => setLoading(false));
    }
  }, [config.provider, config.region]);

  // Fetch AWS SKUs from cache via Function App (or fall back to static JSON)
  useEffect(() => {
    if (config.provider === "AWS" && config.region) {
      setLoading(true);
      api.getAwsPrices(config.region)
        .then((list) => {
          if (list && list.length > 0) {
            setAwsSkus(list);
          } else {
            // Fall back to static JSON if cache is empty
            return fetch("/data/aws-prices.json")
              .then((r) => r.json())
              .then((j) => {
                const all = j.items || j.Items || [];
                setAwsSkus(all.filter((s) => s.region === config.region));
              });
          }
        })
        .catch(() => {
          // Fall back to static JSON
          fetch("/data/aws-prices.json")
            .then((r) => r.json())
            .then((j) => {
              const all = j.items || j.Items || [];
              setAwsSkus(all.filter((s) => s.region === config.region));
            })
            .catch(() => setAwsSkus([]));
        })
        .finally(() => setLoading(false));
    }
  }, [config.provider, config.region]);

  const set = (patch) => onChange({ ...config, ...patch });

  const regions = APPROVED_REGIONS[config.provider] || [];
  const osTypes = Object.keys(osOptions);
  const osVersions = config.osType ? Object.keys(osOptions[config.osType]) : [];

  const skus = config.provider === "Azure" ? azureSkus : awsSkus;

  const vmFamilies = useMemo(() => {
    const fams = new Set();
    skus.forEach((s) => s.family && fams.add(s.family));
    return Array.from(fams).sort();
  }, [skus]);

  const vmSizes = useMemo(() => {
    return skus
      .filter((s) => s.family === config.vmFamily)
      .map((s) => ({
        value: s.sku,
        label: `${s.sku} — $${(s.priceUsd || 0).toFixed(4)}/hr`,
      }));
  }, [skus, config.vmFamily]);

  const handleVmSizeChange = (sku) => {
    const match = skus.find((s) => s.sku === sku);
    onChange({ ...config, vmSize: sku, vmHourlyUsd: match ? match.priceUsd : 0 });
  };

  const diskTypeOptions = config.provider === "AWS" ? AWS_DISK_TYPES : AZURE_DISK_TYPES;

  // Selection order. Changing any field clears every field AFTER it, so the
  // user always works forward through: provider → region → OS type →
  // OS version → VM family → VM size.
  const FIELD_ORDER = ["provider", "region", "osType", "osVersion", "vmFamily", "vmSize"];

  const setField = (k, v) => {
    const next = { ...config, [k]: v };

    // Clear everything downstream of the field that changed.
    const idx = FIELD_ORDER.indexOf(k);
    if (idx !== -1) {
      for (const f of FIELD_ORDER.slice(idx + 1)) next[f] = "";
      // Derived values that hang off the cleared fields.
      next.vmHourlyUsd = 0;
      if (idx < FIELD_ORDER.indexOf("osVersion")) {
        next.hasSQL = false;
        next.oracle = false; next.jboss = false; next.db2 = false;
      }
    }

    if (k === "provider") { next.disks = []; }
    if (k === "osVersion") {
      const cfg = osOptions[next.osType]?.[v];
      next.hasSQL = !!cfg?.hasSQL;
      if (v !== "Other") { next.oracle = false; next.jboss = false; next.db2 = false; }
    }
    onChange(next);
  };

  const disksMonthlyUsd = (config.disks || []).reduce((s, d) => s + (d.monthlyUsd || 0), 0);
  useEffect(() => {
    if ((config.disksMonthlyUsd || 0) !== disksMonthlyUsd) set({ disksMonthlyUsd });
  }, [disksMonthlyUsd]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <Sel t={t} label="Cloud Provider" value={config.provider}
             onChange={(v) => setField("provider", v)} options={PROVIDERS} />
        <Sel t={t} label="Region" value={config.region}
             onChange={(v) => setField("region", v)}
             options={regions.map((r) => ({ value: r.code, label: r.label }))}
             disabled={!config.provider} />
        <Sel t={t} label="OS Type" value={config.osType}
             onChange={(v) => setField("osType", v)} options={osTypes}
             disabled={!config.region} />
      </div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <Sel t={t} label="OS Version" value={config.osVersion}
             onChange={(v) => setField("osVersion", v)} options={osVersions}
             disabled={!config.osType} />
        {/* Searchable VM Family */}
        <SearchableSel t={t} label="VM Family" value={config.vmFamily}
             onChange={(v) => setField("vmFamily", v)}
             options={vmFamilies}
             disabled={!config.osVersion || loading}
             placeholder={loading ? "Loading SKUs…" : "Type to search family…"} />
        {/* Searchable VM Size / SKU */}
        <SearchableSel t={t} label="VM Size / SKU" value={config.vmSize}
             onChange={handleVmSizeChange}
             options={vmSizes}
             disabled={!config.vmFamily}
             placeholder="Type to search SKU…" />
      </div>

      {/* "Other" OS — Oracle/JBoss/DB2 toggles */}
      {config.osVersion === "Other" && (
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {["oracle", "jboss", "db2"].map((k) => (
            <button key={k}
              onClick={() => set({
                oracle: k === "oracle" ? !config.oracle : false,
                jboss: k === "jboss" ? !config.jboss : false,
                db2: k === "db2" ? !config.db2 : false,
              })}
              style={{
                padding: "8px 14px", borderRadius: 10,
                background: config[k] ? "rgba(0,160,225,0.15)" : t?.input,
                border: `1px solid ${config[k] ? "#00A0E1" : t?.inputBorder}`,
                color: config[k] ? "#00A0E1" : t?.textSec,
                fontSize: 12, fontWeight: 600, cursor: "pointer",
              }}>
              {config[k] ? "✓ " : ""}{k.toUpperCase()}
            </button>
          ))}
        </div>
      )}

      {/* Backup size (GB) removed — backup will be re-introduced priced by
          retention period. Calc logic is left intact so it can be re-enabled. */}

      {/* Data disks */}
      <div>
        <div style={{ padding: "10px 14px", borderRadius: "10px 10px 0 0", background: t?.rowHover,
                      border: `1px solid ${t?.cardBorder}`, fontSize: 13, fontWeight: 700, color: t?.textSec }}>
          Data Disks
        </div>
        <div style={{ padding: "12px 14px", borderRadius: "0 0 10px 10px", border: `1px solid ${t?.cardBorder}`, borderTop: "none" }}>
          {(config.disks || []).map((d, i) => (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "end", marginBottom: 8 }}>
              <Sel t={t} label={`Disk ${i + 1} Type`} value={d.type}
                onChange={(v) => { const disks = [...(config.disks || [])]; disks[i] = { ...disks[i], type: v }; set({ disks }); }}
                options={diskTypeOptions} />
              <Sel t={t} label="Size (GB)" value={d.sizeGb ? String(d.sizeGb) : ""}
                onChange={(v) => {
                  const disks = [...(config.disks || [])];
                  disks[i] = { ...disks[i], sizeGb: Number(v), monthlyUsd: estimateDiskMonthly(disks[i].type, Number(v)) };
                  set({ disks });
                }}
                options={DISK_SIZES_GB.map((s) => String(s))} />
              <button onClick={() => set({ disks: (config.disks || []).filter((_, j) => j !== i) })}
                style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid rgba(255,60,60,0.2)",
                         background: "rgba(255,60,60,0.06)", color: "#FF5555", fontSize: 11, fontWeight: 600,
                         cursor: "pointer", height: 38 }}>Remove</button>
            </div>
          ))}
          <button onClick={() => set({ disks: [...(config.disks || []), { type: "", sizeGb: 0, monthlyUsd: 0 }] })}
            style={{ padding: "8px 14px", borderRadius: 8, border: `1px dashed ${t?.inputBorder}`,
                     background: "transparent", color: t?.textSec, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
            + Add Data Disk
          </button>
        </div>
      </div>
    </div>
  );
}

function estimateDiskMonthly(type, sizeGb) {
  if (!type || !sizeGb) return 0;
  const rates = {
    "Standard HDD": 0.05, "Standard SSD": 0.075, "Premium SSD": 0.12,
    "gp3 (General Purpose SSD)": 0.08, "gp2 (General Purpose SSD)": 0.10,
    "io1 (Provisioned IOPS SSD)": 0.125, "io2 (Provisioned IOPS SSD)": 0.125,
    "st1 (Throughput Optimized HDD)": 0.045, "sc1 (Cold HDD)": 0.015,
  };
  return (rates[type] || 0.08) * sizeGb;
}
