// Right-Sizer — a self-contained, rule-based sizing assistant for MPI VMs.
//
// Flow: greet → OS (Windows/Linux) → deployment location → vCPU → RAM →
// recommend the cheapest Azure and AWS instance (in the chosen location's
// nearest approved region) whose vCPU and memory meet-or-exceed the request.
// A secondary FYI flags if the SAME size is cheaper in another approved region.
//
// Notes:
//  - Rule-based: no LLM, no API key. Recommendations are grounded in your live
//    price cache (via /api/GetAzurePrices & /api/GetAwsPrices).
//  - The cache holds Linux on-demand compute only. Windows licence is a separate
//    per-VM line from the MPI rate card, so OS does NOT change which size is
//    cheapest — it only adds a licence note. Specs (vCPU/RAM) are stable and
//    bundled in /data/vm-specs.json; prices are joined live by SKU.
//  - Azure and AWS region footprints differ, so a single LOCATION maps to each
//    provider's nearest approved region, flagged (nearest) when not exact.
//  - Fully isolated: drop <RightSizer user={currentUser} t={t} /> anywhere.
//    Renders a floating top-right launcher plus a bottom-right chat panel.
//  - The chat resets every time the panel is closed, so each open starts fresh.

import { useEffect, useRef, useState } from "react";
import { api } from "../lib/api.js";
import { APPROVED_REGIONS } from "../lib/constants.js";

const HOURS_PER_MONTH = 730;
const ACCENT = "#00A0E1";

// Deployment locations → nearest approved region per provider.
// approx:true means the provider has no region in that location; nearest is used.
const LOCATIONS = [
  { id: "hk",  label: "Hong Kong",      azure: { code: "eastasia" },                    aws: { code: "ap-northeast-1", approx: true } },
  { id: "sg",  label: "Singapore",      azure: { code: "southeastasia" },               aws: { code: "ap-southeast-1" } },
  { id: "jkt", label: "Jakarta",        azure: { code: "southeastasia", approx: true }, aws: { code: "ap-southeast-3" } },
  { id: "tyo", label: "Tokyo",          azure: { code: null },                          aws: { code: "ap-northeast-1" } },
  { id: "weu", label: "Western Europe", azure: { code: "westeurope" },                  aws: { code: "eu-central-1" } },
  { id: "ie",  label: "Ireland",        azure: { code: "northeurope" },                 aws: { code: "eu-west-1" } },
  { id: "ch",  label: "Switzerland",    azure: { code: "switzerlandnorth" },            aws: { code: "eu-central-2" } },
  { id: "use", label: "US East",        azure: { code: "eastus2" },                     aws: { code: "us-east-1" } },
  { id: "usc", label: "US Central",     azure: { code: "centralus" },                   aws: { code: "us-east-1", approx: true } },
];

const PROVIDERS = [
  { name: "Azure", icon: "☁️", key: "azure" },
  { name: "AWS",   icon: "🟧", key: "aws" },
];

const KEYFRAMES = `
@keyframes rsBob    { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-5px)} }
@keyframes rsPulse  { 0%{box-shadow:0 0 0 0 rgba(0,160,225,0.45)} 70%{box-shadow:0 0 0 14px rgba(0,160,225,0)} 100%{box-shadow:0 0 0 0 rgba(0,160,225,0)} }
@keyframes rsPop    { from{opacity:0;transform:translateX(12px) scale(0.92)} to{opacity:1;transform:translateX(0) scale(1)} }
@keyframes rsWiggle { 0%,100%{transform:rotate(0)} 20%{transform:rotate(-14deg)} 60%{transform:rotate(14deg)} }
@keyframes rsSlideIn{ from{opacity:0;transform:translateY(16px) scale(0.98)} to{opacity:1;transform:translateY(0) scale(1)} }
.rs-bob   { animation: rsBob 2.6s ease-in-out infinite; }
.rs-pulse { animation: rsPulse 2.1s ease-out infinite; }
.rs-hint  { animation: rsPop 0.35s ease-out both; }
.rs-emoji { display:inline-block; animation: rsWiggle 2.8s ease-in-out infinite; transform-origin:70% 70%; }
.rs-panel { animation: rsSlideIn 0.28s cubic-bezier(0.22,1,0.36,1) both; }
`;

let _specsCache = null;
async function loadSpecs() {
  if (_specsCache) return _specsCache;
  const resp = await fetch("/data/vm-specs.json");
  if (!resp.ok) throw new Error(`vm-specs.json ${resp.status}`);
  _specsCache = await resp.json();
  return _specsCache;
}

function regionLabelOf(provider, code) {
  const list = APPROVED_REGIONS[provider] || [];
  return (list.find((r) => r.code === code) || {}).label || code;
}

// Scan ALL approved regions for one provider, returning every qualifying SKU row.
async function scanProvider(provider, reqVcpu, reqRam, specMap) {
  const regions = APPROVED_REGIONS[provider] || [];
  const results = await Promise.allSettled(
    regions.map((r) =>
      provider === "Azure" ? api.getAzurePrices(r.code, "") : api.getAwsPrices(r.code)
    )
  );

  let hadData = false;
  const candidates = [];
  results.forEach((res, i) => {
    if (res.status !== "fulfilled" || !Array.isArray(res.value)) return;
    const regionCode = regions[i].code;
    const regionLabel = regions[i].label;
    for (const row of res.value) {
      const price = Number(row.priceUsd);
      if (!isFinite(price) || price <= 0) continue;
      hadData = true;
      const spec = specMap[row.sku];
      if (!spec) continue;
      if (spec.vcpus < reqVcpu || spec.memoryGb < reqRam) continue;
      candidates.push({ sku: row.sku, regionCode, regionLabel, vcpus: spec.vcpus, memoryGb: spec.memoryGb, priceUsd: price });
    }
  });
  return { candidates, hadData };
}

function pickInRegion(candidates, regionCode) {
  const inRegion = candidates.filter((c) => c.regionCode === regionCode);
  if (!inRegion.length) return null;
  return inRegion.reduce((a, b) => (b.priceUsd < a.priceUsd ? b : a));
}

// Same recommended SKU, cheaper in another approved region?
function cheaperElsewhere(candidates, anchored) {
  const sameSku = candidates.filter((c) => c.sku === anchored.sku && c.regionCode !== anchored.regionCode);
  if (!sameSku.length) return null;
  const min = sameSku.reduce((a, b) => (b.priceUsd < a.priceUsd ? b : a));
  if (min.priceUsd >= anchored.priceUsd) return null;
  const pct = Math.round((1 - min.priceUsd / anchored.priceUsd) * 100);
  if (pct < 1) return null;
  return { regionLabel: min.regionLabel, pct };
}

function usd(v, dp = 2) {
  return `$${Number(v || 0).toLocaleString("en-GB", { minimumFractionDigits: dp, maximumFractionDigits: dp })}`;
}

/**
 * Given name from a full name, handling the surname-first convention used in
 * AXA's directory (e.g. "SUPRAMANIAM Minanatha Sivan" -> "Minanatha Sivan").
 * Leading ALL-CAPS tokens are treated as the surname and skipped. Falls back
 * sensibly for ordinary "First Last" names and "Last, First" formats.
 */
function givenNameOf(fullName) {
  const raw = String(fullName || "").trim();
  if (!raw) return "there";

  // "Supramaniam, Minanatha Sivan" -> take the part after the comma.
  if (raw.includes(",")) {
    const after = raw.split(",")[1]?.trim();
    if (after) return titleCaseWords(after);
  }

  const tokens = raw.split(/\s+/).filter(Boolean);
  if (tokens.length === 1) return titleCaseWords(tokens[0]);

  const isAllCaps = (w) => w.length > 1 && w === w.toUpperCase() && /[A-Z]/.test(w);

  // Surname-first: skip the leading ALL-CAPS block, keep the rest.
  if (isAllCaps(tokens[0])) {
    const rest = tokens.filter((w) => !isAllCaps(w));
    if (rest.length) return titleCaseWords(rest.join(" "));
    // Whole name is capitalised — assume surname first, use what follows.
    return titleCaseWords(tokens.slice(1).join(" "));
  }

  // Ordinary "First Last" — the first token is the given name.
  return titleCaseWords(tokens[0]);
}

function titleCaseWords(s) {
  return String(s)
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

export function RightSizer({ user, t }) {
  const [open, setOpen] = useState(false);
  const [hintPinned, setHintPinned] = useState(true);
  const [hover, setHover] = useState(false);
  const [messages, setMessages] = useState([]);
  const [phase, setPhase] = useState("os"); // os → region → vcpu → ram → done
  const [os, setOs] = useState(null);
  const [location, setLocation] = useState(null);
  const [draftVcpu, setDraftVcpu] = useState(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [greeted, setGreeted] = useState(false);
  const scrollRef = useRef(null);

  const firstName = givenNameOf(user?.name);
  const panelBg = t.selectBg; // opaque in both themes
  const showHint = (hintPinned || hover) && !open;

  const push = (from, node) => setMessages((m) => [...m, { id: crypto.randomUUID(), from, node }]);

  useEffect(() => {
    const id = setTimeout(() => setHintPinned(false), 9000);
    return () => clearTimeout(id);
  }, []);

  useEffect(() => {
    if (open && !greeted) {
      setGreeted(true);
      push("bot", `Hi ${firstName} 👋 I'm the Right-Sizer.`);
      push("bot", "I'll help you pick the best-value MPI VM size for the region you're deploying to.");
      push("bot", "First, is this a Windows or Linux VM?");
      setPhase("os");
    }
  }, [open, greeted, firstName]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  function openPanel() {
    setHintPinned(false);
    setHover(false);
    setOpen(true);
  }

  function closePanel() {
    setOpen(false);
    setMessages([]);
    setGreeted(false);
    setPhase("os");
    setOs(null);
    setLocation(null);
    setDraftVcpu(null);
    setInput("");
    setBusy(false);
  }

  const restart = () => {
    setOs(null);
    setLocation(null);
    setDraftVcpu(null);
    setPhase("os");
    push("bot", "Sure — let's start over. Is this a Windows or Linux VM?");
  };

  function chooseOs(value) {
    if (busy) return;
    push("user", value);
    setOs(value);
    push("bot", "Which region will you deploy to?");
    setPhase("region");
  }

  function chooseLocation(loc) {
    if (busy) return;
    push("user", loc.label);
    setLocation(loc);
    push("bot", "How many vCPUs do you need?");
    setPhase("vcpu");
  }

  async function runRecommendation(reqVcpu, reqRam, osVal, loc) {
    setBusy(true);
    push("bot", `Finding the best fit in ${loc.label} for ≥ ${reqVcpu} vCPU and ≥ ${reqRam} GB RAM…`);
    try {
      const specs = await loadSpecs();
      const scans = {};
      await Promise.all(
        PROVIDERS.map(async (p) => {
          scans[p.key] = await scanProvider(p.name, reqVcpu, reqRam, specs[p.key] || {});
        })
      );

      const providerResults = PROVIDERS.map((p) => {
        const { candidates, hadData } = scans[p.key];
        const mapped = loc[p.key];
        if (!mapped.code) return { provider: p.name, icon: p.icon, status: "noRegion" };
        if (!hadData) return { provider: p.name, icon: p.icon, status: "noData" };
        const best = pickInRegion(candidates, mapped.code);
        if (!best) {
          return { provider: p.name, icon: p.icon, status: "noFit", regionLabel: regionLabelOf(p.name, mapped.code), approx: !!mapped.approx };
        }
        return {
          provider: p.name, icon: p.icon, status: "ok", best,
          approx: !!mapped.approx, fyi: cheaperElsewhere(candidates, best),
        };
      });

      push("bot", <ResultCard t={t} results={providerResults} reqVcpu={reqVcpu} reqRam={reqRam} os={osVal} location={loc} />);
      if (osVal === "Windows") {
        push("bot", `Prices are on-demand compute in ${loc.label}. The best-fit size is identical for Windows — a per-VM Windows licence (MPI rate card) and MPI fees are added on top in your estimate.`);
      } else {
        push("bot", `Prices are on-demand compute in ${loc.label}. MPI fees are added on top in your estimate.`);
      }
      push("bot", "Want to try another size?");
      setPhase("done");
    } catch (e) {
      push("bot", `Sorry — I couldn't load the pricing data (${e.message}). Please try again in a moment.`);
      setPhase("done");
    } finally {
      setBusy(false);
    }
  }

  function submit(rawValue) {
    const raw = (rawValue ?? input).toString().trim();
    if (!raw || busy) return;
    setInput("");

    if (phase === "os") {
      if (/^w/i.test(raw)) return chooseOs("Windows");
      if (/^l/i.test(raw)) return chooseOs("Linux");
      push("user", raw);
      push("bot", "Please choose Windows or Linux.");
      return;
    }

    if (phase === "region") {
      const match = LOCATIONS.find((l) => l.label.toLowerCase() === raw.toLowerCase());
      if (match) return chooseLocation(match);
      push("user", raw);
      push("bot", "Please pick one of the listed regions.");
      return;
    }

    const num = parseFloat(raw.replace(/[^0-9.]/g, ""));

    if (phase === "done") {
      if (!isFinite(num) || num <= 0) { restart(); return; }
      const v = Math.max(1, Math.round(num));
      push("user", `${v} vCPU`);
      setDraftVcpu(v);
      push("bot", "And how much RAM (in GB)?");
      setPhase("ram");
      return;
    }

    if (!isFinite(num) || num <= 0) {
      push("user", raw);
      push("bot", "Please enter a positive number.");
      return;
    }

    if (phase === "vcpu") {
      const v = Math.max(1, Math.round(num));
      push("user", `${v} vCPU`);
      setDraftVcpu(v);
      push("bot", "And how much RAM (in GB)?");
      setPhase("ram");
    } else if (phase === "ram") {
      push("user", `${num} GB RAM`);
      runRecommendation(draftVcpu, num, os, location);
    }
  }

  const numChips =
    phase === "vcpu" ? [2, 4, 8, 16, 32] :
    phase === "ram"  ? [8, 16, 32, 64, 128] : [];
  const chipUnit = phase === "vcpu" ? "vCPU" : "GB";
  const inputPlaceholder =
    phase === "os"     ? "Windows or Linux…" :
    phase === "region" ? "Type a region…" :
    phase === "ram"    ? "RAM in GB…" : "Number of vCPUs…";

  const chipBase = {
    borderRadius: 999, cursor: "pointer", border: `1px solid ${ACCENT}40`,
    background: `${ACCENT}12`, color: t.text, fontWeight: 700,
  };

  return (
    <>
      <style>{KEYFRAMES}</style>

      {!open && (
        <div
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
          style={{ position: "fixed", top: 108, right: 24, zIndex: 150, display: "flex", alignItems: "center", gap: 10, fontFamily: "'DM Sans',sans-serif" }}
        >
          {showHint && (
            <div className="rs-hint" style={{
              position: "relative", maxWidth: 210, padding: "10px 30px 10px 12px",
              borderRadius: 12, background: panelBg, border: `1px solid ${t.cardBorder}`,
              color: t.text, fontSize: 12, lineHeight: 1.45, fontWeight: 600,
              boxShadow: "0 12px 34px rgba(0,0,0,0.28)",
            }}>
              👋 Need help sizing your MPI VM? I'll find the cheapest fit.
              <button onClick={() => setHintPinned(false)} aria-label="Dismiss"
                style={{ position: "absolute", top: 6, right: 6, width: 18, height: 18, borderRadius: 6, border: "none", cursor: "pointer", background: "transparent", color: t.textSec, fontSize: 14, lineHeight: 1 }}>×</button>
            </div>
          )}
          <div className="rs-bob">
            <button className="rs-pulse" onClick={openPanel}
              style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "11px 16px", borderRadius: 999, cursor: "pointer", border: "none", background: "linear-gradient(135deg, #00008F, #00A0E1)", color: "#fff", fontWeight: 800, fontSize: 13, whiteSpace: "nowrap" }}>
              <span className="rs-emoji" style={{ fontSize: 16 }}>🤖</span>
              Right-Sizer
            </button>
          </div>
        </div>
      )}

      {open && (
        <div className="rs-panel"
          style={{
            position: "fixed", bottom: 20, right: 20, zIndex: 200,
            width: 372, maxWidth: "calc(100vw - 32px)", height: 560, maxHeight: "calc(100vh - 40px)",
            display: "flex", flexDirection: "column", background: panelBg,
            border: `1px solid ${t.cardBorder}`, borderRadius: 18, overflow: "hidden",
            boxShadow: "0 24px 70px rgba(0,0,0,0.45)", fontFamily: "'DM Sans',sans-serif",
          }}
        >
          <div style={{ padding: "13px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "linear-gradient(135deg, #00008F, #00A0E1)", color: "#fff" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
              <span style={{ fontSize: 18 }}>🤖</span>
              <div>
                <div style={{ fontWeight: 800, fontSize: 14 }}>Right-Sizer</div>
                <div style={{ fontSize: 10, opacity: 0.85 }}>FinOps MPI sizing assistant</div>
              </div>
            </div>
            <button onClick={closePanel} aria-label="Close"
              style={{ width: 28, height: 28, borderRadius: 8, cursor: "pointer", border: "1px solid rgba(255,255,255,0.3)", background: "rgba(255,255,255,0.12)", color: "#fff", fontSize: 15, lineHeight: 1 }}>×</button>
          </div>

          <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "14px 14px 6px", display: "flex", flexDirection: "column", gap: 10 }}>
            {messages.map((m) => (
              <div key={m.id} style={{ display: "flex", justifyContent: m.from === "user" ? "flex-end" : "flex-start" }}>
                <div style={{
                  maxWidth: "86%", padding: "9px 12px", borderRadius: 13, fontSize: 13, lineHeight: 1.5,
                  background: m.from === "user" ? ACCENT : t.input, color: m.from === "user" ? "#fff" : t.text,
                  border: m.from === "user" ? "none" : `1px solid ${t.inputBorder}`,
                  borderBottomRightRadius: m.from === "user" ? 4 : 13, borderBottomLeftRadius: m.from === "user" ? 13 : 4,
                }}>
                  {m.node}
                </div>
              </div>
            ))}
            {busy && (
              <div style={{ display: "flex", justifyContent: "flex-start" }}>
                <div style={{ padding: "9px 12px", borderRadius: 13, fontSize: 13, background: t.input, color: t.textSec, border: `1px solid ${t.inputBorder}` }}>Searching prices…</div>
              </div>
            )}
          </div>

          {/* OS choices */}
          {!busy && phase === "os" && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, padding: "0 14px 8px" }}>
              {[["Windows", "🪟"], ["Linux", "🐧"]].map(([label, icon]) => (
                <button key={label} onClick={() => chooseOs(label)} style={{ ...chipBase, display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 13px", fontSize: 12 }}>
                  <span>{icon}</span>{label}
                </button>
              ))}
            </div>
          )}

          {/* Region choices */}
          {!busy && phase === "region" && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, padding: "0 14px 8px", maxHeight: 96, overflowY: "auto" }}>
              {LOCATIONS.map((l) => (
                <button key={l.id} onClick={() => chooseLocation(l)} style={{ ...chipBase, padding: "5px 11px", fontSize: 12 }}>
                  {l.label}
                </button>
              ))}
            </div>
          )}

          {/* Numeric choices */}
          {!busy && numChips.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, padding: "0 14px 8px" }}>
              {numChips.map((c) => (
                <button key={c} onClick={() => submit(String(c))} style={{ ...chipBase, padding: "5px 11px", fontSize: 12, fontWeight: 600 }}>
                  {c} {chipUnit}
                </button>
              ))}
            </div>
          )}

          {/* Done */}
          {!busy && phase === "done" && (
            <div style={{ display: "flex", gap: 6, padding: "0 14px 8px" }}>
              <button onClick={restart} style={{ padding: "5px 11px", borderRadius: 999, cursor: "pointer", border: `1px solid ${t.inputBorder}`, background: "transparent", color: t.textSec, fontSize: 12, fontWeight: 600 }}>
                Start over
              </button>
            </div>
          )}

          <div style={{ display: "flex", gap: 8, padding: "10px 14px", borderTop: `1px solid ${t.divider}` }}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
              placeholder={inputPlaceholder}
              disabled={busy}
              style={{ flex: 1, padding: "9px 12px", borderRadius: 10, background: t.input, border: `1px solid ${t.inputBorder}`, color: t.text, fontSize: 13, outline: "none" }}
            />
            <button onClick={() => submit()} disabled={busy || !input.trim()}
              style={{ padding: "9px 15px", borderRadius: 10, border: "none", cursor: busy || !input.trim() ? "not-allowed" : "pointer", background: busy || !input.trim() ? t.inputBorder : ACCENT, color: "#fff", fontWeight: 700, fontSize: 13 }}>
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function ProviderBlock({ t, res }) {
  const accentBorder = `1px solid ${t.inputBorder}`;
  return (
    <div style={{ padding: "10px 12px", borderRadius: 11, background: t.input, border: accentBorder }}>
      <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
        <span style={{ fontSize: 14 }}>{res.icon}</span>
        <span style={{ fontWeight: 800, fontSize: 12, color: t.text }}>{res.provider}</span>
      </div>

      {res.status === "ok" && (
        <>
          <div style={{ fontWeight: 800, fontSize: 14, color: t.text, fontFamily: "'DM Mono',monospace" }}>{res.best.sku}</div>
          <div style={{ fontSize: 11, color: t.textSec, marginTop: 2 }}>{res.best.vcpus} vCPU · {res.best.memoryGb} GB RAM</div>
          <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 4, fontSize: 11, fontWeight: 700, color: t.text }}>
            <span style={{ fontSize: 12 }}>📍</span> {res.best.regionLabel}{res.approx ? " (nearest)" : ""}
          </div>
          <div style={{ display: "flex", gap: 14, marginTop: 8 }}>
            <div>
              <div style={{ fontSize: 9, color: t.textSec, textTransform: "uppercase", letterSpacing: "0.06em" }}>Hourly</div>
              <div style={{ fontWeight: 800, fontSize: 13, color: ACCENT, fontFamily: "'DM Mono',monospace" }}>{usd(res.best.priceUsd, 4)}</div>
            </div>
            <div>
              <div style={{ fontSize: 9, color: t.textSec, textTransform: "uppercase", letterSpacing: "0.06em" }}>~ / month</div>
              <div style={{ fontWeight: 800, fontSize: 13, color: t.text, fontFamily: "'DM Mono',monospace" }}>{usd(res.best.priceUsd * HOURS_PER_MONTH, 0)}</div>
            </div>
          </div>
          {res.fyi && (
            <div style={{ marginTop: 8, padding: "6px 9px", borderRadius: 8, background: `${ACCENT}12`, border: `1px solid ${ACCENT}30`, fontSize: 11, color: t.textSec }}>
              💡 Same size is ~{res.fyi.pct}% cheaper in {res.fyi.regionLabel}
            </div>
          )}
        </>
      )}

      {res.status === "noFit" && (
        <div style={{ fontSize: 12, color: t.textSec }}>No approved SKU in {res.regionLabel}{res.approx ? " (nearest)" : ""} meets this spec.</div>
      )}
      {res.status === "noRegion" && (
        <div style={{ fontSize: 12, color: t.textSec }}>No approved {res.provider} region near this location.</div>
      )}
      {res.status === "noData" && (
        <div style={{ fontSize: 12, color: t.textSec }}>No cached pricing yet — prime this provider's cache first.</div>
      )}
    </div>
  );
}

function ResultCard({ t, results, reqVcpu, reqRam, os, location }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 240 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: t.textSec, textTransform: "uppercase", letterSpacing: "0.07em" }}>
        Best fit · ≥ {reqVcpu} vCPU / {reqRam} GB · {location.label}{os ? ` · ${os}` : ""}
      </div>
      {results.map((r) => (
        <ProviderBlock key={r.provider} t={t} res={r} />
      ))}
    </div>
  );
}
