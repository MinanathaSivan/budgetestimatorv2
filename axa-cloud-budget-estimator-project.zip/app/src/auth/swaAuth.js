// Azure Static Web Apps built-in authentication.
// SWA handles the Entra ID flow at the edge — we just read the current
// principal from /.auth/me. No MSAL, no token acquisition.
//
// References:
//   https://learn.microsoft.com/azure/static-web-apps/authentication-authorization
//   https://learn.microsoft.com/azure/static-web-apps/user-information

const LOGIN_PROVIDER = "aad"; // Azure Active Directory (Entra ID)

/** Redirect the browser to the SWA login endpoint. */
export function login(postLoginRedirect = "/") {
  const target = encodeURIComponent(postLoginRedirect);
  window.location.href = `/.auth/login/${LOGIN_PROVIDER}?post_login_redirect_uri=${target}`;
}

/** Redirect the browser to the SWA logout endpoint. */
export function logout() {
  window.location.href = `/.auth/logout`;
}

/**
 * Fetch the current client principal. Returns null when not signed in.
 * Shape: { identityProvider, userId, userDetails, userRoles, claims }
 * `userDetails` is the email for AAD users.
 */
export async function getClientPrincipal() {
  try {
    const resp = await fetch("/.auth/me", { credentials: "include" });
    if (!resp.ok) return null;
    const payload = await resp.json();
    return payload.clientPrincipal || null;
  } catch {
    return null;
  }
}
