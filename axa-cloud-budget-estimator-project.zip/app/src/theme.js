export function buildTheme(dark) {
  return {
    bg:          dark ? "#070B14"                  : "#F4F6F9",
    card:        dark ? "rgba(255,255,255,0.025)"  : "#FFFFFF",
    cardBorder:  dark ? "rgba(255,255,255,0.06)"   : "#E2E6ED",
    header:      dark ? "rgba(7,11,20,0.84)"       : "rgba(255,255,255,0.92)",
    headerBorder:dark ? "rgba(255,255,255,0.05)"   : "#E2E6ED",
    text:        dark ? "#E8ECF4"                  : "#1A1D23",
    textSec:     dark ? "rgba(255,255,255,0.45)"   : "#6B7280",
    textMuted:   dark ? "rgba(255,255,255,0.25)"   : "#9CA3AF",
    input:       dark ? "rgba(255,255,255,0.05)"   : "#F9FAFB",
    inputBorder: dark ? "rgba(255,255,255,0.1)"    : "#D1D5DB",
    divider:     dark ? "rgba(255,255,255,0.04)"   : "#F0F1F3",
    rowHover:    dark ? "rgba(255,255,255,0.03)"   : "#F9FAFB",
    selectBg:    dark ? "#0D1220"                  : "#FFFFFF",
    shadow:      dark ? "none"                     : "0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)",
  };
}
