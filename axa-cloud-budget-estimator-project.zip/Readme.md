# AXA Cloud Budget Estimator — Technical Documentation

## Table of Contents

1. [Solution Overview](#2-solution-overview)
1. [Architecture Diagram](#3-architecture-diagram)
1. [Repository Structure](#4-repository-structure)
1. [Authentication & Authorization Flow](#5-authentication--authorization-flow)
1. [Request Lifecycle — End to End](#6-request-lifecycle--end-to-end)
1. [MPI Cost Calculation Engine](#7-mpi-cost-calculation-engine)
1. [Azure & AWS Price Cache](#8-azure--aws-price-cache)
1. [Table Storage Schema](#9-table-storage-schema)
1. [Deployment Pipeline](#10-deployment-pipeline)
1. [Evergreening & Maintenance Guide](#11-evergreening--maintenance-guide)
1. [Troubleshooting Playbook](#12-troubleshooting-playbook)

-----

### Repo structure

```
/
├── .gitignore
├── azure-pipelines.yml              # main deploy pipeline
├── azure-pipelines-refresh.yml      # weekly price refresh pipeline
├── app/                             # React SPA (Vite)
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   ├── public/
│   │   ├── staticwebapp.config.json # SWA routing + auth config
│   │   └── data/
│   │       └── aws-prices.json      # static fallback AWS prices
│   └── src/
│       ├── App.jsx
│       ├── main.jsx
│       ├── theme.js
│       ├── auth/
│       │   └── swaAuth.js
│       ├── lib/
│       │   ├── api.js
│       │   ├── calc.js
│       │   ├── constants.js
│       │   ├── currency.js
│       │   └── excelExport.js
│       ├── components/
│       │   ├── UI.jsx
│       │   └── MpiVmForm.jsx
│       └── pages/
│           ├── Estimator.jsx
│           ├── PricingPanel.jsx
│           └── IAM.jsx
├── api/                             # Azure Functions (Node 20)
│   ├── package.json
│   ├── host.json
│   ├── shared/
│   │   ├── auth.js
│   │   ├── tables.js
│   │   ├── azurePricing.js
│   │   └── awsPricing.js
│   ├── GetMe/
│   ├── GetProducts/
│   ├── UpdateProduct/
│   ├── GetEstimates/
│   ├── SaveEstimate/
│   ├── UpdateEstimate/
│   ├── DeleteEstimate/
│   ├── GetUsers/
│   ├── AddUser/
│   ├── UpdateUser/
│   ├── RemoveUser/
│   ├── GetPricingAuditLog/
│   ├── GetAzurePrices/
│   ├── GetAwsPrices/
│   ├── RefreshAzurePricesNow/
│   └── RefreshAwsPricesNow/
├── data/
│   └── aws-prices.json              # source copy (copied into app/public/data/ by pipeline)
└── scripts/
    ├── package.json
    └── seed.js
```

-----

## 2. Solution Overview

The AXA Cloud Budget Estimator is an internal web application for estimating cloud infrastructure costs across four products: MPI (Managed Public Cloud Infrastructure), NAS/Fileshare, POD (Managed Container Runtime), and Terraform Workspace. It replaces a legacy vanilla HTML/JS tool that only supported MPI.

|Aspect              |Technology                                                                      |
|--------------------|--------------------------------------------------------------------------------|
|Frontend            |React 18 + Vite, no CSS framework (inline styles), DM Sans font                 |
|Backend             |Azure Functions v4 (Node 20), HTTP triggers only                                |
|Hosting             |Azure Static Web Apps (Standard tier)                                           |
|Authentication      |SWA Easy Auth with custom Entra ID app registration                             |
|Authorization       |Application-level via `UserRoles` table in Azure Table Storage                  |
|Data storage        |Azure Table Storage (6 tables)                                                  |
|Cloud pricing source|Azure Retail Prices API (cached weekly), AWS Pricing API via SDK (cached weekly)|
|CI/CD               |Azure DevOps Pipelines (2 pipelines: deploy + weekly refresh)                   |
|Export              |Multi-sheet Excel via SheetJS (client-side)                                     |

-----

## 3. Architecture Diagram

```
                    ┌─────────────────────────────────────────────────────┐
                    │            Azure Static Web App (Standard)          │
  Browser           │          z-ats-estimator-dv01-ae1-stapp01          │
  (AXA Entra ID)    │                                                     │
       │            │   GET /              → React SPA (app/dist/)        │
       │ ──────────►│   GET /.auth/me      → SWA auth (full claims)       │
       │            │   GET /.auth/login/* → Entra ID OAuth2 flow         │
       │            │   ALL /api/*         → Managed Azure Functions       │
       │            │                                                     │
       │            │   x-ms-client-principal header injected on /api/*   │
       │            │   (stripped claims — no email for some users)       │
       │            └────────────────────────┬────────────────────────────┘
       │                                     │
       │  x-user-email header                │  TABLES_CONNECTION
       │  (SPA forwards from /.auth/me)      │  AWS_ACCESS_KEY_ID
       │                                     │  AWS_SECRET_ACCESS_KEY
       │                                     ▼
       │                          ┌──────────────────────────┐
       │                          │  Azure Table Storage      │
       │                          │  zatsestimtordvae1sto01   │
       │                          │                           │
       │                          │  Tables:                  │
       │                          │   • Products (rate card)  │
       │                          │   • UserRoles             │
       │                          │   • Estimates             │
       │                          │   • PricingAuditLog       │
       │                          │   • AzurePriceCache       │
       │                          │   • AwsPriceCache         │
       │                          └──────────────────────────┘
       │
       │  /.auth/me response includes full claims
       │  SPA extracts email → sends as x-user-email header
       │  to all /api/* calls
```

-----

## 4. Repository Structure

See Section 1 (final clean repo structure) for the complete tree.

Key design decisions:

- **`app/public/staticwebapp.config.json`** — SWA routing config placed in Vite’s `public/` folder so Vite copies it verbatim into `app/dist/` during `npm run build`. This avoids pipeline-time substitution.
- **Tenant ID hardcoded in config** — the `openIdIssuer` URL contains the literal tenant ID (`2da8bd67-...`). This is intentional. For a single-tenant internal tool, hardcoding is safer than build-time substitution which has been a source of deployment failures.
- **One `function.json` + `index.js` per Function folder** — classic Azure Functions v4 folder-per-function model. No `scriptFile` needed. The `api/package.json` must NOT contain a `"main"` field (this caused a “file does not exist” error in earlier iterations).
- **`api/shared/`** — common modules (`auth.js`, `tables.js`, `azurePricing.js`, `awsPricing.js`) imported by Functions via `require("../shared/...")`.

-----

## 5. Authentication & Authorization Flow

### Overview

Authentication and authorization are separated:

- **Authentication** = “Is this person who they claim to be?” → handled by SWA Easy Auth + Entra ID
- **Authorization** = “Is this person allowed to use this app, and what role do they have?” → handled by application code checking the `UserRoles` table

Any user in the AXA Entra ID tenant can complete the authentication flow. Only users whose email or UPN exists in the `UserRoles` table can use the application.

### Step-by-step flow

```
┌──────────┐     ┌──────────────────┐     ┌──────────────┐     ┌──────────────┐
│  Browser  │     │  SWA Easy Auth   │     │  Entra ID    │     │  Functions   │
└─────┬─────┘     └────────┬─────────┘     └──────┬───────┘     └──────┬───────┘
      │                    │                      │                    │
      │  1. GET /          │                      │                    │
      │───────────────────►│                      │                    │
      │  ◄── index.html    │                      │                    │
      │                    │                      │                    │
      │  2. SPA mounts, calls /.auth/me           │                    │
      │───────────────────►│                      │                    │
      │  ◄── { clientPrincipal: null }            │                    │
      │                    │                      │                    │
      │  3. User clicks "Sign in with AXA"        │                    │
      │     SPA navigates to /.auth/login/aad     │                    │
      │───────────────────►│                      │                    │
      │                    │  4. Redirect to       │                    │
      │                    │  login.microsoftonline│                    │
      │  ◄─────────────────│──────────────────────►│                    │
      │                    │                      │                    │
      │  5. User enters AXA credentials           │                    │
      │──────────────────────────────────────────►│                    │
      │                    │                      │                    │
      │  6. Entra issues tokens, redirects to     │                    │
      │     /.auth/login/aad/callback             │                    │
      │  ◄────────────────────────────────────────│                    │
      │───────────────────►│                      │                    │
      │                    │  7. SWA validates token, sets              │
      │                    │     session cookies, redirects to /       │
      │  ◄─────────────────│                      │                    │
      │                    │                      │                    │
      │  8. SPA mounts again, calls /.auth/me     │                    │
      │───────────────────►│                      │                    │
      │  ◄── { clientPrincipal: { userDetails,    │                    │
      │       claims: [...including email...] } } │                    │
      │                    │                      │                    │
      │  9. SPA extracts email from claims,       │                    │
      │     caches it, sends to /api/GetMe        │                    │
      │     with x-user-email header              │                    │
      │───────────────────►│                      │                    │
      │                    │  10. SWA injects      │                    │
      │                    │  x-ms-client-principal│                    │
      │                    │  header (STRIPPED claims)                  │
      │                    │──────────────────────────────────────────►│
      │                    │                      │                    │
      │                    │                      │  11. auth.js:       │
      │                    │                      │  - Decode principal │
      │                    │                      │  - Extract UPN      │
      │                    │                      │  - Read x-user-email│
      │                    │                      │  - findUser(email,  │
      │                    │                      │    upn) in table    │
      │                    │                      │  - Backfill UPN     │
      │                    │                      │  - Return user obj  │
      │  ◄────────────────────────────────────────────────────────────│
      │     { email, upn, name, role, ... }       │                    │
      │                    │                      │                    │
      │  12. SPA renders based on role            │                    │
      │      (super_admin → 3 tabs)               │                    │
      │      (user → 1 tab)                       │                    │
```

### File-by-file trace

|Step|File                                              |What happens                                                                                                                                              |
|----|--------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
|1-2 |`app/src/auth/swaAuth.js` → `getClientPrincipal()`|Calls `/.auth/me`, returns the full client principal or null                                                                                              |
|3   |`app/src/auth/swaAuth.js` → `login()`             |Redirects browser to `/.auth/login/aad?post_login_redirect_uri=/`                                                                                         |
|4-7 |SWA platform + Entra ID                           |OAuth2 authorization code flow with PKCE. SWA handles token exchange using `AAD_CLIENT_ID` + `AAD_CLIENT_SECRET` from app settings                        |
|8   |`app/src/App.jsx` → `useEffect`                   |Calls `getClientPrincipal()` again, this time gets the full principal with claims                                                                         |
|9   |`app/src/App.jsx` → `useEffect`                   |Extracts `emailaddress` claim from principal, calls `setCachedEmail()` so all future API calls include `x-user-email` header                              |
|9   |`app/src/lib/api.js` → `request()`                |Every fetch to `/api/*` includes `x-user-email` header + `credentials: "include"` for the session cookie                                                  |
|10  |SWA platform                                      |SWA validates the session cookie, injects a **stripped** `x-ms-client-principal` header (may not contain claims), forwards request to the managed Function|
|11  |`api/shared/auth.js` → `authorize()`              |Decodes `x-ms-client-principal` to get UPN, reads `x-user-email` header to get email, calls `findUser(email, upn)`                                        |
|11  |`api/shared/tables.js` → `findUser()`             |Tries three lookups in order: (1) RowKey match on email, (2) RowKey match on UPN, (3) scan `upn` field for UPN match                                      |
|11  |`api/shared/tables.js` → `backfillUpn()`          |If the user was found by email but has no UPN stored, writes the UPN from the token onto the row for future fast lookups                                  |
|12  |`api/GetMe/index.js`                              |Returns `{ email, upn, name, role, assignedProducts, avatar }`                                                                                            |
|12  |`app/src/App.jsx`                                 |Sets `me` state, renders tabs based on `me.role`                                                                                                          |

### Why `x-user-email` is safe

The `x-user-email` header is sent by the SPA, not by SWA. A malicious user could theoretically set it to someone else’s email. This is safe because:

1. The request must already be authenticated — `x-ms-client-principal` is verified by SWA at the edge. An unauthenticated request never reaches the Function.
1. The header only determines **which user row to look up**. It does not grant additional privileges. If someone sets `x-user-email` to a super_admin’s email, they still need to be authenticated as a real AXA user, and the response reveals the other user’s role (not useful).
1. If spoofing is a concern, the header can be cross-checked against the authenticated UPN (e.g., verify that the email and UPN belong to the same person in Entra). This is a future hardening step, not needed for an internal tool.

### Role hierarchy

|Role           |Budget Estimator                  |Pricing Panel           |IAM Management|
|---------------|--------------------------------|------------------------|--------------|
|`user`         |✅ View + use                    |❌                       |❌             |
|`pricing_admin`|✅ View + use                    |✅ Assigned products only|❌             |
|`super_admin`  |✅ View + use + see all estimates|✅ All products          |✅ Full access |

-----

## 6. Request Lifecycle — End to End

Example: user clicks “Save Estimate” in the Budget Estimator.

```
Browser                          SWA                              Function
   │                              │                                  │
   │  POST /api/SaveEstimate      │                                  │
   │  Headers:                    │                                  │
   │    Cookie: AppService...     │                                  │
   │    x-user-email: minanathasivan.supramaniam@axa.com    │                                  │
   │  Body: { projectName, items }│                                  │
   │─────────────────────────────►│                                  │
   │                              │  Validate session cookie          │
   │                              │  Inject x-ms-client-principal     │
   │                              │  Forward to Function runtime      │
   │                              │─────────────────────────────────►│
   │                              │                                  │
   │                              │  api/SaveEstimate/index.js:       │
   │                              │  1. withAuth() wrapper calls      │
   │                              │     authorize(req)                │
   │                              │                                  │
   │                              │  api/shared/auth.js:              │
   │                              │  2. decodePrincipal(req) →        │
   │                              │     { userDetails: "J123@login" } │
   │                              │  3. Read x-user-email header →    │
   │                              │     "minanathasivan.supramaniam@axa.com"                │
   │                              │  4. findUser("minanathasivan.supramaniam@axa.com",      │
   │                              │     "j123@login.axa")             │
   │                              │                                  │
   │                              │  api/shared/tables.js:            │
   │                              │  5. getUserByEmail("minanathasivan.supramaniam@axa.com")│
   │                              │     → Table lookup: PK="Users",  │
   │                              │       RK="minanathasivan.supramaniam@axa.com"          │
   │                              │     → Returns user row with role  │
   │                              │  6. backfillUpn if needed         │
   │                              │                                  │
   │                              │  api/SaveEstimate/index.js:       │
   │                              │  7. Validate body                 │
   │                              │  8. upsertEstimate() →            │
   │                              │     Table: Estimates              │
   │                              │     PK = user.oid                 │
   │                              │     RK = estimate UUID            │
   │                              │  9. Return 200 + saved entity     │
   │                              │◄─────────────────────────────────│
   │◄─────────────────────────────│                                  │
   │  200 OK { id, projectName }  │                                  │
```

-----

## 7. MPI Cost Calculation Engine

File: `app/src/lib/calc.js`

This is the **single source of truth** for all MPI pricing. The formula:

```
perVmMonthlyEur =
      (vmHourlyUsd × 730) / fxRate           Base VM compute (from cloud cache)
    + (Σ disk.monthlyUsd) / fxRate            Data disks
    + license[windows|linux|sql|oracle|jboss] OS/DB license (from rate card)
    + mpi.productFee                          MPI product fee (per VM — was flat, bug fixed)
    + mpi.distributedPattern                  Distributed pattern services (per VM)
    + mpi.dbServices[sql|oracle|db2]          DB services — only if DB pattern selected
    + mpi.middleware                           Middleware — only if DB or JBoss selected
    + (backupGb × backup[aws|azure])          Backup per GB (auto-skipped in no-backup regions)

itemMonthlyEur = perVmMonthlyEur × vmCount
itemAnnualEur  = itemMonthlyEur × 12
```

### Key functions in `calc.js`

|Function                         |Purpose                                                                                                 |
|---------------------------------|--------------------------------------------------------------------------------------------------------|
|`resolveLicenseKey(cfg)`         |Determines which license applies (windows/linux/sql/oracle/jboss) based on OS type, version, and options|
|`resolveDbKey(cfg)`              |Determines which DB pattern applies (sql/oracle/db2/null)                                               |
|`needsMiddleware(cfg)`           |Returns true if middleware fee applies (any DB pattern or JBoss)                                        |
|`calcMpiItem(rateCard, cfg)`     |Main MPI calculator — returns breakdown, totals, warnings                                               |
|`calcNasItem(rateCard, tb)`      |NAS: rate × TB                                                                                          |
|`calcPodItem(rateCard, pods)`    |POD: rate × pods                                                                                        |
|`calcTerraformItem(rateCard, ws)`|Terraform: rate × workspaces                                                                            |
|`buildRateCard(rows)`            |Converts flat Table Storage rows into nested rate card object                                           |
|`calcEstimateTotal(items)`       |Sums monthly/annual across all items in an estimate                                                     |

### Currency handling

- All rate card values are stored in **EUR** (canonical currency)
- VM base prices come from cloud providers in **USD** and are converted to EUR using `fxRate`
- Display currency (EUR/USD) is a view toggle in the header — does not affect stored values
- `fxRate` (USD per 1 EUR) is a row in the `Products` table, editable via the Pricing Panel

-----

## 8. Azure & AWS Price Cache

### Azure

- **Source**: `https://prices.azure.com/api/retail/prices` (public, no auth needed)
- **Function**: `RefreshAzurePricesNow` — one region per call
- **Cache table**: `AzurePriceCache` (PartitionKey = region code, RowKey = SKU name)
- **Filter**: `serviceName = 'Virtual Machines'`, `priceType = 'Consumption'`, Linux only (Windows license added from rate card)
- **Excluded**: spot instances, low-priority, reservations
- **Family derivation**: heuristic from `armSkuName` prefix (e.g. `Standard_D4s_v5` → `D-Series (General)`)
- **Batch writes**: 100 entities per `TableTransaction` to minimize round trips

### AWS

- **Source**: AWS Pricing API (`GetProducts` command via `@aws-sdk/client-pricing`)
- **Auth**: `AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY` stored as SWA app settings
- **Function**: `RefreshAwsPricesNow` — one region per call
- **Cache table**: `AwsPriceCache` (PartitionKey = region code, RowKey = instance type)
- **Filter**: Linux, on-demand, shared tenancy, no pre-installed SW, 247 whitelisted instance types
- **Region mapping**: AWS Pricing API uses location names not codes (e.g. `EU (Frankfurt)` not `eu-central-1`)
- **Important**: AWS SDK v3 returns `PriceList` items as `String` objects (capital S), which must be parsed with `JSON.parse(String(item))` not just `JSON.parse(item)`

### Refresh schedule

The `azure-pipelines-refresh.yml` pipeline runs every Sunday at 02:00 UTC and calls both Azure and AWS refresh endpoints for all approved regions sequentially. Each call takes 20–60 seconds. Total wall time: ~10 minutes.

### First-time priming

After initial deployment, the cache tables are empty. The super_admin must prime them manually from the browser console (F12 → Console tab):

```javascript
// Azure — 7 regions, one at a time
fetch('/api/RefreshAzurePricesNow?region=westeurope', {method:'POST', credentials:'include'}).then(r=>r.json()).then(console.log)
// ... repeat for each region

// AWS — 7 regions, one at a time  
fetch('/api/RefreshAwsPricesNow?region=eu-central-1', {method:'POST', credentials:'include'}).then(r=>r.json()).then(console.log)
// ... repeat for each region
```

-----

## 9. Table Storage Schema

### Products (rate card)

|Field       |Type  |Example                                                          |
|------------|------|-----------------------------------------------------------------|
|PartitionKey|string|`"RateCard"` (always)                                            |
|RowKey      |string|`"mpi_productFee"`, `"nas_fileshare"`, `"config_fxRate"`         |
|label       |string|`"MPI Product Fee"`                                              |
|unit        |string|`"per VM / month"`                                               |
|price       |double|`145.12`                                                         |
|currency    |string|`"EUR"`                                                          |
|productGroup|string|`"mpi"`, `"nas"`, `"pod"`, `"terraform"`, or `""` for config rows|

### UserRoles

|Field           |Type         |Example                                                         |
|----------------|-------------|----------------------------------------------------------------|
|PartitionKey    |string       |`"Users"` (always)                                              |
|RowKey          |string       |`"minanathasivan.supramaniam@axa.com"` (email, lowercased)      |
|name            |string       |`"Minanatha Sivan"`                                             |
|role            |string       |`"user"` / `"pricing_admin"` / `"super_admin"`                  |
|avatar          |string       |`"MS"`                                                          |
|upn             |string       |`"j123ab@login.axa"` (auto-populated on first sign-in, or empty)|
|assignedProducts|string (JSON)|`'["mpi","nas"]'` or `'[]'`                                     |

### Estimates

|Field          |Type         |Example                           |
|---------------|-------------|----------------------------------|
|PartitionKey   |string       |User’s OID (from Entra token)     |
|RowKey         |string       |UUID                              |
|ownerName      |string       |`"Minanatha Sivan"`               |
|projectName    |string       |`"Project Alpha"`                 |
|items          |string (JSON)|Serialized array of estimate items|
|totalMonthlyEur|double       |`5432.10`                         |
|totalAnnualEur |double       |`65185.20`                        |
|createdAt      |string       |ISO 8601                          |
|updatedAt      |string       |ISO 8601                          |

### PricingAuditLog

|Field       |Type  |Example                                                     |
|------------|------|------------------------------------------------------------|
|PartitionKey|string|`"202604"` (yyyymm)                                         |
|RowKey      |string|Reverse-tick + random suffix (natural newest-first ordering)|
|timestamp   |string|ISO 8601                                                    |
|userOid     |string|OID of the user who made the change                         |
|userName    |string|`"Sivan Minanatha"`                                         |
|itemKey     |string|`"mpi_productFee"`                                          |
|oldPrice    |double|`145.12`                                                    |
|newPrice    |double|`150.00`                                                    |

### AzurePriceCache

|Field        |Type  |Example                           |
|-------------|------|----------------------------------|
|PartitionKey |string|`"westeurope"` (region code)      |
|RowKey       |string|`"Standard_D4s_v5"` (ARM SKU name)|
|family       |string|`"D-Series (General)"`            |
|armSkuName   |string|`"Standard_D4s_v5"`               |
|productName  |string|`"Virtual Machines Dsv5 Series"`  |
|meterName    |string|`"D4s v5"`                        |
|priceUsd     |double|`0.192` (hourly)                  |
|currency     |string|`"USD"`                           |
|lastRefreshed|string|ISO 8601                          |

### AwsPriceCache

|Field        |Type  |Example                       |
|-------------|------|------------------------------|
|PartitionKey |string|`"eu-central-1"` (region code)|
|RowKey       |string|`"m6i.xlarge"` (instance type)|
|family       |string|`"m6i (General)"`             |
|instanceType |string|`"m6i.xlarge"`                |
|priceUsd     |double|`0.192` (hourly)              |
|currency     |string|`"USD"`                       |
|lastRefreshed|string|ISO 8601                      |

-----

## 10. Deployment Pipeline

### Main pipeline (`azure-pipelines.yml`)

Triggers on push to `main`. Steps:

1. Install Node 20
1. `cd app && npm ci && npm run build` → produces `app/dist/`
1. Copy `data/aws-prices.json` into `app/dist/data/`
1. `AzureStaticWebApp@0` task uploads `app/dist/` (SPA) + `api/` (Functions)
1. SWA’s Oryx build installs `api/` dependencies and deploys both

Required pipeline variable: `AZURE_STATIC_WEB_APPS_API_TOKEN` (secret)

### Refresh pipeline (`azure-pipelines-refresh.yml`)

Cron schedule: `0 2 * * 0` (Sunday 02:00 UTC). Steps:

1. Loop through 7 Azure regions, call `POST /api/RefreshAzurePricesNow?region=<code>` with `x-refresh-secret` header
1. Loop through 7 AWS regions, call `POST /api/RefreshAwsPricesNow?region=<code>` with `x-refresh-secret` header

Required pipeline variables: `SWA_HOSTNAME` (secret), `REFRESH_SECRET` (secret)

-----

## 11. Evergreening & Maintenance Guide

### Weekly (automated)

|Item               |What happens                                        |Owner               |
|-------------------|----------------------------------------------------|--------------------|
|Azure price refresh|Pipeline calls `RefreshAzurePricesNow` for 7 regions|Automated (pipeline)|
|AWS price refresh  |Pipeline calls `RefreshAwsPricesNow` for 7 regions  |Automated (pipeline)|

Verify the weekly pipeline is running by checking Azure DevOps → Pipelines → `axa-cost-estimator-refresh-prices` → Recent runs. If it shows failures, check the run log for the specific region that failed.

### Monthly

|Item                        |Action                                                                     |Details                                                                      |
|----------------------------|---------------------------------------------------------------------------|-----------------------------------------------------------------------------|
|Verify price cache freshness|Check `lastRefreshed` dates in `AzurePriceCache` and `AwsPriceCache` tables|If stale > 2 weeks, the refresh pipeline may be failing. Check pipeline logs.|
|Review pricing audit log    |Pricing Panel → Audit Log                                                  |Ensure no unauthorized changes                                               |
|Check SWA Function logs     |Azure Portal → SWA → Application Insights → Failures                       |Look for 500 errors or unusual patterns                                      |

### Quarterly

|Item                              |Action                                                               |Details                                                                                                                                                 |
|----------------------------------|---------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
|Update npm dependencies           |Run `npm outdated` in both `app/` and `api/`                         |Focus on security patches: `npm audit fix`                                                                                                              |
|Review approved regions           |Check with Cloud Broker team if any new regions were added           |Update `app/src/lib/constants.js` → `APPROVED_REGIONS`, SWA app setting `APPROVED_AZURE_REGIONS`, and `api/shared/awsPricing.js` → `REGION_LOCATION_MAP`|
|Review approved AWS instance types|Check with Cloud Broker team                                         |Update `REQUIRED_INSTANCE_TYPES` in `api/shared/awsPricing.js`                                                                                          |
|Rotate AWS credentials            |Generate new access key, update SWA app settings                     |`az staticwebapp appsettings set --setting-names "AWS_ACCESS_KEY_ID=..." "AWS_SECRET_ACCESS_KEY=..."`                                                   |
|Check Entra app registration      |Azure Portal → Entra → App registrations → `AXA Cloud Budget Estimator`|Verify client secret hasn’t expired (24-month validity from creation). If expiring soon, regenerate and update SWA’s `AAD_CLIENT_SECRET` app setting.   |

### Semi-annually

|Item                            |Action                                                                                          |Details                                                                                                                                                |
|--------------------------------|------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|
|Review FX rate                  |Pricing Panel → Configuration → FX rate                                                         |Compare against current EUR/USD market rate. New estimates use the updated rate immediately. Existing saved estimates retain their original EUR values.|
|Dependency major version updates|Check for React, Vite, Azure SDK, AWS SDK major versions                                        |Test locally before pushing. Major version bumps may require code changes.                                                                             |
|SWA runtime updates             |Check [Azure SWA release notes](https://learn.microsoft.com/azure/static-web-apps/release-notes)|SWA runtime updates automatically. Check for breaking changes in managed Functions behavior.                                                           |

### Annually

|Item                            |Action                                                                                |Details                                                                                                                                      |
|--------------------------------|--------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
|**Entra client secret rotation**|Regenerate before the 24-month expiry                                                 |Run: `az ad app credential reset --id <APP_ID> --display-name "swa-easy-auth-YYYY" --years 2` then update `AAD_CLIENT_SECRET` SWA app setting|
|Review rate card accuracy       |Compare `Products` table values against actual MPI/NAS/POD/Terraform contractual rates|Rate card values may drift from actual contracted prices over time. Coordinate with commercial team.                                         |
|Archive old estimates           |Consider deleting estimates older than 2 years from the `Estimates` table             |Currently no automated cleanup. Can be done via Cloud Shell or a one-time script.                                                            |
|Review and update IAM users     |Audit `UserRoles` table for leavers/movers                                            |Remove users who have left AXA. Update roles for team changes.                                                                               |

### Version tracking

Track these versions and check for updates:

|Component              |Current version|Where to check                             |
|-----------------------|---------------|-------------------------------------------|
|React                  |^18.2.0        |`app/package.json`                         |
|Vite                   |^5.1.0         |`app/package.json`                         |
|@azure/data-tables     |^13.2.2        |`api/package.json`                         |
|@aws-sdk/client-pricing|^3.500.0       |`api/package.json`                         |
|SheetJS (xlsx)         |^0.18.5        |`app/package.json`                         |
|Node.js runtime        |20.x           |Pipeline `nodeVersion` variable + SWA Oryx |
|Azure Functions runtime|~4             |`api/host.json` → extensionBundle          |
|SWA CLI (local dev)    |latest         |`npm install -g @azure/static-web-apps-cli`|

### SWA application settings reference

All settings stored on the SWA resource (Azure Portal → SWA → Configuration → Application settings):

|Setting                 |Purpose                                     |Rotation needed?                 |
|------------------------|--------------------------------------------|---------------------------------|
|`AAD_CLIENT_ID`         |Entra app registration client ID            |No (permanent)                   |
|`AAD_CLIENT_SECRET`     |Entra app registration secret               |Yes — every 24 months            |
|`TABLES_CONNECTION`     |Storage account connection string           |Only if storage key is rotated   |
|`AZURE_PRICES_API`      |`https://prices.azure.com/api/retail/prices`|No (public API)                  |
|`APPROVED_AZURE_REGIONS`|Comma-separated region codes                |Update when new regions approved |
|`AWS_ACCESS_KEY_ID`     |AWS IAM user access key                     |Yes — quarterly recommended      |
|`AWS_SECRET_ACCESS_KEY` |AWS IAM user secret key                     |Yes — quarterly recommended      |
|`REFRESH_SECRET`        |Shared secret for the refresh pipeline      |Rotate annually or if compromised|

-----

## 12. Troubleshooting Playbook

### “Need admin approval” on sign-in

**Cause**: SWA’s default Entra provider is blocked by AXA’s tenant policy, or the custom registration needs admin consent.
**Fix**: Ensure `AAD_CLIENT_ID` and `AAD_CLIENT_SECRET` are set on the SWA. If still blocked, run `az ad app permission admin-consent --id <CLIENT_ID>`.

### “Not authorized — contact a Super Admin”

**Cause**: The user’s email (or UPN) doesn’t match any row in `UserRoles`.
**Diagnosis**: Ask the user to open `https://<host>/.auth/me` and find their `emailaddress` claim value. Compare against the RowKey in the table.
**Fix**: Add the exact email from the claim to `UserRoles` via IAM tab or Cloud Shell.

### User’s UPN column stays “pending” after sign-in

**Cause**: The `backfillUpn` function failed silently or the claims don’t include the email so the lookup matched by UPN RowKey instead.
**Diagnosis**: Check App Insights for “UPN backfill failed” log entries.
**Fix**: The backfill only runs when the user is found by email RowKey. If found by UPN, no backfill happens (the UPN is already the match key). Manually update via Cloud Shell if needed.

### VM size dropdown is empty

**Cause**: Price cache not primed for that provider/region.
**Fix**: Prime from browser console: `fetch('/api/RefreshAzurePricesNow?region=<code>', {method:'POST', credentials:'include'}).then(r=>r.json()).then(console.log)`

### AWS refresh returns `count: 0`

**Cause**: AWS SDK returns `String` objects (capital S) for `PriceList` items, which must be parsed with `JSON.parse(String(item))`.
**Fix**: Ensure `api/shared/awsPricing.js` uses `JSON.parse(String(item))`, not `typeof item === "string" ? JSON.parse(item) : item`.

### “Backend call failure” on refresh

**Cause**: SWA gateway timeout (230 seconds). The refresh for a single region took too long.
**Fix**: Ensure the refresh endpoint processes ONE region per call, not all at once.

### 500 error with empty body on any Function

**Cause**: Usually a missing dependency or a `require()` crash at module load time.
**Diagnosis**: Check App Insights → Failures → exception details.
**Common fixes**:

- Ensure `api/package.json` does NOT have a `"main"` field
- Ensure all dependencies are listed in `api/package.json`
- Ensure `api/shared/*.js` files are present in the deployment

### Redirect loop (ERR_TOO_MANY_REDIRECTS)

**Cause**: `responseOverrides` in `staticwebapp.config.json` interfering with SWA’s auth flow.
**Fix**: Remove all `responseOverrides`. The SPA handles signed-out state via React, not redirects.

### Price changes don’t take effect

**Cause**: Browser caching the old rate card.
**Fix**: Hard refresh (Ctrl+Shift+R) or clear cache. The SPA fetches the rate card from `/api/GetProducts` on every mount — there’s no service worker or local cache.

### Estimate save fails with 500

**Cause**: Usually `TABLES_CONNECTION` is missing or malformed.
**Fix**: Verify the setting: `az staticwebapp appsettings list --name <swa> --resource-group <rg> --query "properties.TABLES_CONNECTION"`
