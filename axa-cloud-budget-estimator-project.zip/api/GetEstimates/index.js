const { withAuth } = require("../shared/auth");
const { listEstimates } = require("../shared/tables");

module.exports = withAuth(async (context, req, user) => {
  const isSuper = user.role === "super_admin";
  const rows = await listEstimates(user.oid, isSuper);
  context.res = { status: 200, body: rows };
});
