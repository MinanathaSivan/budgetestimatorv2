const { withAuth } = require("../shared/auth");

module.exports = withAuth(async (context, req, user) => {
  context.res = {
    status: 200,
    headers: { "Content-Type": "application/json" },
    body: {
      email: user.email,
      upn: user.upn,
      name: user.name,
      oid: user.oid,
      role: user.role,
      assignedProducts: user.assignedProducts,
      avatar: user.avatar,
    },
  };
});