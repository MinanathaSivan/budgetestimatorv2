const { withAuth } = require("../shared/auth");
const { getProduct, upsertProduct, appendAudit } = require("../shared/tables");

// Maps a rate-card rowKey to the logical product an admin must be assigned to.
// Returns null for global/config rows that only super_admin may edit.
function productForRowKey(rowKey) {
  if (rowKey === "config_fxRate") return null;
  if (rowKey.startsWith("nas_")) return "nas";
  if (rowKey.startsWith("pod_")) return "pod";
  if (rowKey.startsWith("terraform_")) return "terraform";
  if (rowKey.startsWith("mpi_")) return "mpi";
  return null;
}

module.exports = withAuth(["super_admin", "pricing_admin"], async (context, req, user) => {
  const { rowKey, price } = req.body || {};
  if (!rowKey || typeof price !== "number" || price < 0) {
    const e = new Error("rowKey and non-negative price required"); e.status = 400; throw e;
  }

  const product = productForRowKey(rowKey);
  if (user.role === "pricing_admin") {
    if (!product) {
      const e = new Error("Only super_admin can edit global config"); e.status = 403; throw e;
    }
    if (!user.assignedProducts.includes(product)) {
      const e = new Error(`Not assigned to product ${product}`); e.status = 403; throw e;
    }
  }

  const existing = await getProduct(rowKey);
  if (!existing) {
    const e = new Error(`Unknown rate card row: ${rowKey}`); e.status = 404; throw e;
  }

  await upsertProduct({ ...existing, rowKey, price });
  await appendAudit({
    userOid: user.oid,
    userName: user.name,
    itemKey: rowKey,
    oldPrice: existing.price,
    newPrice: price,
  });

  context.res = { status: 200, body: { ok: true, rowKey, oldPrice: existing.price, newPrice: price } };
});
