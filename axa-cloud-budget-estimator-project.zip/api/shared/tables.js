const { TableClient, odata } = require("@azure/data-tables");

const CONN = process.env.TABLES_CONNECTION || process.env.AzureWebJobsStorage;

const TABLES = {
  Products:         "Products",
  Estimates:        "Estimates",
  PricingAuditLog:  "PricingAuditLog",
  UserRoles:        "UserRoles",
  AzurePriceCache:  "AzurePriceCache",
  AwsPriceCache:    "AwsPriceCache",
};

function client(name) {
  return TableClient.fromConnectionString(CONN, name, { allowInsecureConnection: false });
}

async function ensureTables() {
  for (const name of Object.values(TABLES)) {
    try { await client(name).createTable(); }
    catch (e) { if (e.statusCode !== 409) throw e; }
  }
}

function decodeJson(entity, fields) {
  const out = { ...entity };
  for (const f of fields) {
    if (out[f] && typeof out[f] === "string") {
      try { out[f] = JSON.parse(out[f]); } catch { /* leave as string */ }
    }
  }
  return out;
}

function parseUserEntity(e) {
  return decodeJson({
    email: e.rowKey,
    name: e.name,
    role: e.role,
    avatar: e.avatar,
    upn: e.upn || "",
    autoProvisioned: e.autoProvisioned || false,
    firstSeen: e.firstSeen || "",
    assignedProducts: e.assignedProducts || "[]",
  }, ["assignedProducts"]);
}

// --- Products (rate card) -------------------------------------------------
async function listProducts() {
  const c = client(TABLES.Products);
  const out = [];
  for await (const e of c.listEntities({ queryOptions: { filter: odata`PartitionKey eq 'RateCard'` } })) {
    out.push({
      rowKey: e.rowKey,
      label: e.label,
      unit: e.unit,
      price: Number(e.price),
      currency: e.currency || "EUR",
      productGroup: e.productGroup || null,
    });
  }
  return out;
}

async function getProduct(rowKey) {
  try {
    const e = await client(TABLES.Products).getEntity("RateCard", rowKey);
    return { rowKey: e.rowKey, label: e.label, unit: e.unit, price: Number(e.price), currency: e.currency || "EUR", productGroup: e.productGroup || null };
  } catch (err) {
    if (err.statusCode === 404) return null;
    throw err;
  }
}

async function upsertProduct(entity) {
  await client(TABLES.Products).upsertEntity(
    { partitionKey: "RateCard", ...entity },
    "Merge",
  );
}

// --- UserRoles ------------------------------------------------------------

/** Look up user by exact RowKey (email or UPN — whatever was stored as RowKey). */
async function getUserByEmail(email) {
  try {
    const e = await client(TABLES.UserRoles).getEntity("Users", email.toLowerCase());
    return parseUserEntity(e);
  } catch (err) {
    if (err.statusCode === 404) return null;
    throw err;
  }
}

/** Scan for a user whose `upn` field matches (fallback when RowKey lookup fails). */
async function getUserByUpn(upn) {
  const c = client(TABLES.UserRoles);
  const lower = upn.toLowerCase();
  try {
    for await (const e of c.listEntities({
      queryOptions: { filter: odata`PartitionKey eq 'Users' and upn eq ${lower}` }
    })) {
      return parseUserEntity(e);
    }
  } catch { /* scan failed — return null */ }
  return null;
}

/**
 * Find a user by trying all known identifiers in order:
 *   1. RowKey exact match on email
 *   2. RowKey exact match on UPN
 *   3. Scan the upn field for a match
 */
async function findUser(email, upn) {
  let user = null;
  if (email) user = await getUserByEmail(email);
  if (!user && upn) user = await getUserByEmail(upn);  // UPN might be the RowKey
  if (!user && upn) user = await getUserByUpn(upn);     // scan upn field
  return user;
}

/**
 * After successful sign-in, backfill the UPN onto the user's row so
 * future lookups by UPN field scan will work.
 */
async function backfillUpn(email, upn) {
  if (!email || !upn) return;
  try {
    const e = await client(TABLES.UserRoles).getEntity("Users", email.toLowerCase());
    if (!e.upn || e.upn !== upn.toLowerCase()) {
      await client(TABLES.UserRoles).upsertEntity({
        partitionKey: "Users",
        rowKey: email.toLowerCase(),
        name: e.name,
        role: e.role,
        avatar: e.avatar,
        upn: upn.toLowerCase(),
        assignedProducts: e.assignedProducts || "[]",
      }, "Replace");
    }
  } catch { /* row doesn't exist or backfill failed — non-critical */ }
}

async function listUsers() {
  const c = client(TABLES.UserRoles);
  const out = [];
  for await (const e of c.listEntities({ queryOptions: { filter: odata`PartitionKey eq 'Users'` } })) {
    out.push(parseUserEntity(e));
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}

async function upsertUser(u) {
  await client(TABLES.UserRoles).upsertEntity(
    {
      partitionKey: "Users",
      rowKey: u.email.toLowerCase(),
      name: u.name,
      role: u.role,
      avatar: u.avatar || u.name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2),
      upn: (u.upn || "").toLowerCase(),
      assignedProducts: JSON.stringify(u.assignedProducts || []),
    },
    "Replace",
  );
}

/**
 * Update ONLY the display name and avatar of an existing user row.
 * Uses Merge so role, assignedProducts and every other field are preserved.
 * Used to repair rows auto-provisioned with the UPN as the name.
 */
async function repairUserName(email, name, avatar) {
  if (!email || !name) return;
  await client(TABLES.UserRoles).updateEntity(
    {
      partitionKey: "Users",
      rowKey: String(email).toLowerCase(),
      name,
      avatar: avatar || name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2),
    },
    "Merge",
  );
}

async function deleteUser(email) {
  try { await client(TABLES.UserRoles).deleteEntity("Users", email.toLowerCase()); }
  catch (err) { if (err.statusCode !== 404) throw err; }
}

/**
 * Auto-provision a new user with default 'user' role on first sign-in.
 * Called when a signed-in (authenticated) user is not yet in UserRoles.
 * Idempotent: if the row already exists, it is not overwritten.
 */
async function autoProvisionUser({ email, upn, name, avatar }) {
  const rowKey = (email || upn).toLowerCase();
  if (!rowKey) return null;

  const c = client(TABLES.UserRoles);

  // Don't clobber an existing row (race condition safety)
  try {
    const existing = await c.getEntity("Users", rowKey);
    return parseUserEntity(existing);
  } catch (err) {
    if (err.statusCode !== 404) throw err;
    // 404 = doesn't exist yet, proceed to create
  }

  const entity = {
    partitionKey: "Users",
    rowKey,
    name: name || rowKey,
    role: "user",
    avatar: avatar || (name ? name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2) : rowKey.slice(0, 2).toUpperCase()),
    upn: (upn || "").toLowerCase(),
    assignedProducts: "[]",
    autoProvisioned: true,
    firstSeen: new Date().toISOString(),
  };

  await c.upsertEntity(entity, "Replace");
  return parseUserEntity(entity);
}

// --- Estimates ------------------------------------------------------------
async function listEstimates(userOid, isSuperAdmin) {
  const c = client(TABLES.Estimates);
  const filter = isSuperAdmin ? undefined : odata`PartitionKey eq ${userOid}`;
  const out = [];
  for await (const e of c.listEntities({ queryOptions: { filter } })) {
    out.push(decodeJson({
      id: e.rowKey,
      ownerOid: e.partitionKey,
      ownerName: e.ownerName,
      projectName: e.projectName,
      items: e.items || "[]",
      totalMonthlyEur: Number(e.totalMonthlyEur || 0),
      totalAnnualEur: Number(e.totalAnnualEur || 0),
      createdAt: e.createdAt,
      updatedAt: e.updatedAt,
    }, ["items"]));
  }
  return out.sort((a, b) => (b.updatedAt || b.createdAt).localeCompare(a.updatedAt || a.createdAt));
}

async function getEstimate(userOid, id) {
  try {
    const e = await client(TABLES.Estimates).getEntity(userOid, id);
    return decodeJson({
      id: e.rowKey,
      ownerOid: e.partitionKey,
      ownerName: e.ownerName,
      projectName: e.projectName,
      items: e.items || "[]",
      totalMonthlyEur: Number(e.totalMonthlyEur || 0),
      totalAnnualEur: Number(e.totalAnnualEur || 0),
      createdAt: e.createdAt,
      updatedAt: e.updatedAt,
    }, ["items"]);
  } catch (err) {
    if (err.statusCode === 404) return null;
    throw err;
  }
}

async function findEstimateById(id) {
  const c = client(TABLES.Estimates);
  for await (const e of c.listEntities({ queryOptions: { filter: odata`RowKey eq ${id}` } })) {
    return { partitionKey: e.partitionKey, rowKey: e.rowKey };
  }
  return null;
}

async function upsertEstimate(entity) {
  await client(TABLES.Estimates).upsertEntity(
    {
      partitionKey: entity.ownerOid,
      rowKey: entity.id,
      ownerName: entity.ownerName,
      projectName: entity.projectName,
      items: JSON.stringify(entity.items || []),
      totalMonthlyEur: entity.totalMonthlyEur || 0,
      totalAnnualEur: entity.totalAnnualEur || 0,
      createdAt: entity.createdAt,
      updatedAt: entity.updatedAt,
    },
    "Replace",
  );
}

async function deleteEstimateById(ownerOid, id) {
  try { await client(TABLES.Estimates).deleteEntity(ownerOid, id); }
  catch (err) { if (err.statusCode !== 404) throw err; }
}

// --- PricingAuditLog ------------------------------------------------------
async function appendAudit(entry) {
  const now = new Date();
  const yyyymm = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}`;
  const reverseTick = String(9_999_999_999_999 - now.getTime()).padStart(14, "0");
  const rowKey = `${reverseTick}_${Math.random().toString(36).slice(2, 8)}`;
  await client(TABLES.PricingAuditLog).createEntity({
    partitionKey: yyyymm,
    rowKey,
    timestamp: now.toISOString(),
    userOid: entry.userOid,
    userName: entry.userName,
    itemKey: entry.itemKey,
    oldPrice: entry.oldPrice,
    newPrice: entry.newPrice,
  });
}

async function listAudit(limit = 200) {
  const c = client(TABLES.PricingAuditLog);
  const out = [];
  for await (const e of c.listEntities()) {
    out.push({
      id: `${e.partitionKey}_${e.rowKey}`,
      timestamp: e.timestamp,
      userOid: e.userOid,
      userName: e.userName,
      itemKey: e.itemKey,
      oldPrice: Number(e.oldPrice),
      newPrice: Number(e.newPrice),
    });
    if (out.length >= limit) break;
  }
  return out.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

// --- AzurePriceCache ------------------------------------------------------
async function listAzurePrices(region, family) {
  const c = client(TABLES.AzurePriceCache);
  const filter = family
    ? odata`PartitionKey eq ${region} and family eq ${family}`
    : odata`PartitionKey eq ${region}`;
  const out = [];
  for await (const e of c.listEntities({ queryOptions: { filter } })) {
    out.push({
      region: e.partitionKey,
      sku: e.rowKey,
      family: e.family,
      armSkuName: e.armSkuName,
      productName: e.productName,
      meterName: e.meterName,
      priceUsd: Number(e.priceUsd),
      currency: e.currency || "USD",
      lastRefreshed: e.lastRefreshed,
    });
  }
  return out;
}

async function upsertAzurePrice(entity) {
  await client(TABLES.AzurePriceCache).upsertEntity(
    { partitionKey: entity.region, rowKey: entity.sku, ...entity },
    "Replace",
  );
}

// --- AwsPriceCache --------------------------------------------------------
async function listAwsPrices(region, family) {
  const c = client(TABLES.AwsPriceCache);
  const filter = family
    ? odata`PartitionKey eq ${region} and family eq ${family}`
    : odata`PartitionKey eq ${region}`;
  const out = [];
  for await (const e of c.listEntities({ queryOptions: { filter } })) {
    out.push({
      region: e.partitionKey,
      sku: e.rowKey,
      family: e.family,
      instanceType: e.instanceType,
      vcpus: Number(e.vcpus || 0),
      memoryGb: Number(e.memoryGb || 0),
      storage: e.storage || "EBS Only",
      priceUsd: Number(e.priceUsd),
      currency: e.currency || "USD",
      lastRefreshed: e.lastRefreshed,
    });
  }
  return out;
}

async function upsertAwsPrice(entity) {
  await client(TABLES.AwsPriceCache).upsertEntity(
    { partitionKey: entity.region, rowKey: entity.sku, ...entity },
    "Replace",
  );
}

module.exports = {
  TABLES,
  ensureTables,
  listProducts, getProduct, upsertProduct,
  getUserByEmail, getUserByUpn, findUser, backfillUpn, autoProvisionUser,
  listUsers, upsertUser, deleteUser, repairUserName,
  listEstimates, getEstimate, findEstimateById, upsertEstimate, deleteEstimateById,
  appendAudit, listAudit,
  listAzurePrices, upsertAzurePrice,
  listAwsPrices, upsertAwsPrice,
};