// Azure Retail Prices → AzurePriceCache refresher.
// Refreshes ONE region per call so we stay under SWA's 230-second gateway
// timeout. Uses batch upserts (100 entities per transaction) to minimise
// Table Storage round trips.

const { TableClient, TableTransaction } = require("@azure/data-tables");

const API = process.env.AZURE_PRICES_API || "https://prices.azure.com/api/retail/prices";

function deriveFamily(armSkuName) {
  if (!armSkuName) return "Other";
  const m = armSkuName.match(/^Standard_([A-Z]+)/i);
  if (!m) return "Other";
  const letter = m[1].toUpperCase();
  const map = {
    A: "A-Series (Basic)",      B: "B-Series (Burstable)",
    D: "D-Series (General)",    DS: "D-Series (General)",
    E: "E-Series (Memory)",     ES: "E-Series (Memory)",
    F: "F-Series (Compute)",    FS: "F-Series (Compute)",
    G: "G-Series (Memory + Storage)",
    H: "H-Series (HPC)",        L: "L-Series (Storage)",
    M: "M-Series (Memory)",     N: "N-Series (GPU)",
  };
  return map[letter] || `${letter}-Series`;
}

/**
 * Refresh a single region. Safe to call concurrently for different regions.
 * Uses native global fetch (Node 20+). No node-fetch dependency.
 */
async function refreshRegion(context, region) {
  const conn = process.env.TABLES_CONNECTION;
  if (!conn) throw new Error("TABLES_CONNECTION not set");

  const client = TableClient.fromConnectionString(conn, "AzurePriceCache");
  try { await client.createTable(); }
  catch (e) { if (e.statusCode !== 409) throw e; }

  const filter = [
    `serviceName eq 'Virtual Machines'`,
    `priceType eq 'Consumption'`,
    `armRegionName eq '${region}'`,
  ].join(" and ");

  let url = `${API}?$filter=${encodeURIComponent(filter)}`;
  const now = new Date().toISOString();
  let pageCount = 0;

  // Deduplicate by rowKey (armSkuName) across ALL pages before writing.
  // The Retail Prices API can return several meters for the same SKU
  // (regional vs global meters, productName variants), which previously put
  // two entities with the same RowKey into one TableTransaction — Table
  // Storage rejects that with "The batch request contains multiple changes
  // with same row key." We keep exactly one entity per SKU: the lowest
  // positive price, which is the base Linux compute meter.
  const bySku = new Map();

  while (url) {
    pageCount++;
    const resp = await fetch(url);
    if (!resp.ok) {
      throw new Error(`Azure pricing API ${resp.status} for region ${region} on page ${pageCount}`);
    }
    const json = await resp.json();
    const items = json.Items || [];

    for (const it of items) {
      if (it.productName && /Windows/i.test(it.productName)) continue;
      if (it.skuName && /(Spot|Low Priority)/i.test(it.skuName)) continue;
      if (it.reservationTerm) continue;
      if (!it.armSkuName) continue;
      if (typeof it.retailPrice !== "number" || it.retailPrice <= 0) continue;

      const existing = bySku.get(it.armSkuName);
      if (existing && existing.priceUsd <= it.retailPrice) continue;

      bySku.set(it.armSkuName, {
        partitionKey: region,
        rowKey: it.armSkuName,
        family: deriveFamily(it.armSkuName),
        armSkuName: it.armSkuName,
        productName: it.productName,
        meterName: it.meterName,
        priceUsd: it.retailPrice,
        currency: it.currencyCode || "USD",
        lastRefreshed: now,
      });
    }
    url = json.NextPageLink || null;
  }

  // Flush in chunks of 100. RowKeys are unique across the whole set, so they
  // are unique within every batch.
  const entities = [...bySku.values()];
  for (let i = 0; i < entities.length; i += 100) {
    const tx = new TableTransaction();
    for (const ent of entities.slice(i, i + 100)) tx.upsertEntity(ent, "Replace");
    await client.submitTransaction(tx.actions);
  }

  const count = entities.length;
  context.log(`region ${region}: ${count} SKUs in ${pageCount} pages`);
  return { region, count, pages: pageCount };
}

module.exports = { refreshRegion };