const { PricingClient, GetProductsCommand } = require("@aws-sdk/client-pricing");
const { TableClient, TableTransaction } = require("@azure/data-tables");

const REQUIRED_INSTANCE_TYPES = new Set([
  "c5.large","c5.xlarge","c5.2xlarge","c5.4xlarge",
  "c6i.large","c6i.xlarge","c6i.2xlarge","c6i.4xlarge","c6i.8xlarge","c6i.12xlarge","c6i.16xlarge","c6i.24xlarge","c6i.32xlarge","c6i.metal",
  "c6id.large","c6id.xlarge","c6id.2xlarge","c6id.4xlarge","c6id.8xlarge","c6id.12xlarge","c6id.16xlarge","c6id.24xlarge","c6id.32xlarge","c6id.metal",
  "c7i.large","c7i.xlarge","c7i.2xlarge","c7i.4xlarge","c7i.8xlarge","c7i.12xlarge","c7i.16xlarge","c7i.24xlarge","c7i.48xlarge","c7i.metal-24xl","c7i.metal-48xl",
  "i4i.large","i4i.xlarge","i4i.2xlarge","i4i.4xlarge",
  "m4.2xlarge",
  "m5.large","m5.xlarge","m5.2xlarge","m5.4xlarge","m5.8xlarge","m5.16xlarge",
  "m5n.large","m5n.xlarge","m5n.2xlarge","m5n.4xlarge","m5n.8xlarge","m5n.12xlarge","m5n.16xlarge","m5n.24xlarge","m5n.metal",
  "m6a.large","m6a.xlarge","m6a.2xlarge","m6a.4xlarge","m6a.8xlarge","m6a.12xlarge","m6a.16xlarge","m6a.24xlarge","m6a.32xlarge","m6a.48xlarge","m6a.metal",
  "m6g.medium","m6g.large","m6g.xlarge","m6g.2xlarge","m6g.4xlarge","m6g.8xlarge","m6g.12xlarge","m6g.16xlarge","m6g.metal",
  "m6i.large","m6i.xlarge","m6i.2xlarge","m6i.4xlarge","m6i.8xlarge","m6i.12xlarge","m6i.16xlarge","m6i.24xlarge","m6i.32xlarge","m6i.metal",
  "m6id.large","m6id.xlarge","m6id.2xlarge","m6id.4xlarge","m6id.8xlarge","m6id.12xlarge","m6id.16xlarge","m6id.24xlarge","m6id.32xlarge","m6id.metal",
  "m6in.large","m6in.xlarge","m6in.2xlarge","m6in.4xlarge","m6in.8xlarge","m6in.12xlarge","m6in.16xlarge","m6in.24xlarge","m6in.32xlarge","m6in.metal",
  "m7a.medium","m7a.large","m7a.xlarge","m7a.2xlarge","m7a.4xlarge","m7a.8xlarge","m7a.12xlarge","m7a.16xlarge","m7a.24xlarge","m7a.32xlarge","m7a.48xlarge","m7a.metal-48xl",
  "m7i-flex.large","m7i-flex.xlarge","m7i-flex.2xlarge","m7i-flex.4xlarge","m7i-flex.8xlarge",
  "m7i.large","m7i.xlarge","m7i.2xlarge","m7i.4xlarge","m7i.8xlarge","m7i.12xlarge","m7i.16xlarge","m7i.24xlarge","m7i.48xlarge","m7i.metal-24xl","m7i.metal-48xl",
  "r5.large","r5.xlarge","r5.2xlarge","r5.4xlarge","r5.8xlarge","r5.12xlarge","r5.16xlarge","r5.24xlarge",
  "r6a.large","r6a.xlarge","r6a.2xlarge","r6a.4xlarge","r6a.8xlarge","r6a.12xlarge","r6a.16xlarge","r6a.24xlarge","r6a.32xlarge","r6a.48xlarge","r6a.metal",
  "r6i.large","r6i.xlarge","r6i.2xlarge","r6i.4xlarge","r6i.8xlarge","r6i.12xlarge","r6i.16xlarge","r6i.24xlarge","r6i.32xlarge","r6i.metal",
  "r6id.large","r6id.xlarge","r6id.2xlarge","r6id.4xlarge","r6id.8xlarge","r6id.12xlarge","r6id.16xlarge","r6id.24xlarge","r6id.32xlarge","r6id.metal",
  "r6in.large","r6in.xlarge","r6in.2xlarge","r6in.4xlarge","r6in.8xlarge","r6in.12xlarge","r6in.16xlarge","r6in.24xlarge","r6in.32xlarge","r6in.metal",
  "r7a.medium","r7a.large","r7a.xlarge","r7a.2xlarge","r7a.4xlarge","r7a.8xlarge","r7a.12xlarge","r7a.16xlarge","r7a.24xlarge","r7a.32xlarge","r7a.48xlarge","r7a.metal-48xl",
  "r7i.large","r7i.xlarge","r7i.2xlarge","r7i.4xlarge","r7i.8xlarge","r7i.12xlarge","r7i.16xlarge","r7i.24xlarge","r7i.48xlarge","r7i.metal-24xl","r7i.metal-48xl",
  "r7iz.large","r7iz.xlarge","r7iz.2xlarge","r7iz.4xlarge","r7iz.8xlarge","r7iz.12xlarge","r7iz.16xlarge","r7iz.32xlarge","r7iz.metal-16xl","r7iz.metal-32xl",
  "t2.nano","t2.micro","t2.small","t2.medium","t2.large","t2.xlarge","t2.2xlarge",
  "t3.micro","t3.small","t3.medium","t3.large","t3.xlarge","t3.2xlarge",
  "x1e.4xlarge",
  "x2idn.16xlarge","x2idn.24xlarge","x2idn.32xlarge","x2idn.metal",
  "x2iedn.xlarge","x2iedn.2xlarge","x2iedn.4xlarge","x2iedn.8xlarge","x2iedn.16xlarge","x2iedn.24xlarge","x2iedn.32xlarge","x2iedn.metal",
  "x2iezn.2xlarge","x2iezn.4xlarge","x2iezn.6xlarge","x2iezn.8xlarge","x2iezn.12xlarge","x2iezn.metal",
]);

const REGION_LOCATION_MAP = {
  "us-east-1":      "US East (N. Virginia)",
  "ap-northeast-1": "Asia Pacific (Tokyo)",
  "ap-southeast-1": "Asia Pacific (Singapore)",
  "ap-southeast-3": "Asia Pacific (Jakarta)",
  "eu-central-1":   "EU (Frankfurt)",
  "eu-central-2":   "Europe (Zurich)",
  "eu-west-1":      "EU (Ireland)",
};

const APPROVED_AWS_REGIONS = Object.keys(REGION_LOCATION_MAP);

function deriveFamily(instanceType) {
  if (!instanceType) return "Other";
  const prefix = instanceType.split(".")[0];
  const letter = prefix.replace(/[0-9].*/g, "");
  const map = {
    m: "General", t: "Burstable", c: "Compute", r: "Memory",
    i: "Storage", x: "Memory", d: "Storage", h: "Storage",
    p: "GPU", g: "GPU",
  };
  const role = map[letter[0]] || "General";
  return `${prefix} (${role})`;
}

async function refreshAwsRegion(context, region) {
  const location = REGION_LOCATION_MAP[region];
  if (!location) throw new Error(`Unknown AWS region: ${region}`);

  const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
  const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
  if (!accessKeyId || !secretAccessKey) {
    throw new Error("AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY not configured");
  }

  const conn = process.env.TABLES_CONNECTION;
  if (!conn) throw new Error("TABLES_CONNECTION not set");

  const pricingClient = new PricingClient({
    region: "us-east-1",
    credentials: { accessKeyId, secretAccessKey },
  });

  const tableClient = TableClient.fromConnectionString(conn, "AwsPriceCache");
  try { await tableClient.createTable(); }
  catch (e) { if (e.statusCode !== 409) throw e; }

  const now = new Date().toISOString();
  const prices = {};
  let nextToken;
  let pageCount = 0;

  // Diagnostic counters
  const diag = {
    totalItemsSeen: 0,
    priceListLengths: [],
    itemTypes: {},          // typeof each item
    withInstanceType: 0,
    instanceTypesSeen: [],  // first 10 unique instance types found
    sampleItem: null,       // first raw item for structure inspection
    sampleParsed: null,     // first item after parsing
    sampleAttrs: null,      // first item's attributes
  };

  do {
    pageCount++;
    const cmd = new GetProductsCommand({
      ServiceCode: "AmazonEC2",
      Filters: [
        { Type: "TERM_MATCH", Field: "location", Value: location },
        { Type: "TERM_MATCH", Field: "operatingSystem", Value: "Linux" },
        { Type: "TERM_MATCH", Field: "tenancy", Value: "Shared" },
        { Type: "TERM_MATCH", Field: "capacitystatus", Value: "Used" },
        { Type: "TERM_MATCH", Field: "preInstalledSw", Value: "NA" },
      ],
      NextToken: nextToken,
    });

    const resp = await pricingClient.send(cmd);
    nextToken = resp.NextToken;

    const list = resp.PriceList || [];
    diag.priceListLengths.push(list.length);
    diag.totalItemsSeen += list.length;

    for (const item of list) {
      // Track the type of the first item
      if (!diag.sampleItem) {
        diag.sampleItem = typeof item === "string" ? item.slice(0, 500) : JSON.stringify(item).slice(0, 500);
        diag.itemTypes[typeof item] = (diag.itemTypes[typeof item] || 0) + 1;
      } else {
        diag.itemTypes[typeof item] = (diag.itemTypes[typeof item] || 0) + 1;
      }

      let product;
      try {
        product = JSON.parse(String(item));
      } catch (parseErr) {
        diag.parseError = parseErr.message;
        continue;
      }

      if (!diag.sampleParsed) {
        diag.sampleParsed = {
          topKeys: Object.keys(product),
          hasProduct: !!product.product,
          hasAttributes: !!product?.product?.attributes,
        };
        if (product?.product?.attributes) {
          diag.sampleAttrs = Object.keys(product.product.attributes).slice(0, 15);
        }
      }

      const attrs = product?.product?.attributes || {};
      const instanceType = attrs.instanceType;

      if (instanceType) {
        diag.withInstanceType++;
        if (diag.instanceTypesSeen.length < 10) {
          diag.instanceTypesSeen.push(instanceType);
        }
      }

      if (!instanceType || !REQUIRED_INSTANCE_TYPES.has(instanceType)) continue;

      const onDemand = product?.terms?.OnDemand || {};
      for (const term of Object.values(onDemand)) {
        for (const pd of Object.values(term.priceDimensions || {})) {
          if (pd.unit && pd.unit.includes("Hrs")) {
            const usd = parseFloat(pd.pricePerUnit?.USD || "0");
            if (usd > 0) prices[instanceType] = usd;
          }
        }
      }
    }
  } while (nextToken);

  // Write to Table Storage in batches of 100
  const entries = Object.entries(prices);
  let pending = [];
  let count = 0;

  async function flushBatch() {
    if (pending.length === 0) return;
    const tx = new TableTransaction();
    for (const ent of pending) tx.upsertEntity(ent, "Replace");
    await tableClient.submitTransaction(tx.actions);
    pending = [];
  }

  for (const [instanceType, hourlyPrice] of entries) {
    const family = deriveFamily(instanceType);
    pending.push({
      partitionKey: region,
      rowKey: instanceType,
      family,
      sku: instanceType,
      instanceType,
      vcpus: 0,
      memoryGb: 0,
      storage: "EBS Only",
      priceUsd: hourlyPrice,
      currency: "USD",
      lastRefreshed: now,
    });
    count++;
    if (pending.length >= 100) await flushBatch();
  }
  await flushBatch();

  context.log(`AWS ${region}: ${count} SKUs in ${pageCount} pages`);
  return { region, count, pages: pageCount, diag };
}

module.exports = { refreshAwsRegion, APPROVED_AWS_REGIONS };