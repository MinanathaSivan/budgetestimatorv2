const { withAuth } = require("../shared/auth");
const { getEstimate, findEstimateById, deleteEstimateById } = require("../shared/tables");

module.exports = withAuth(async (context, req, user) => {
  const { id } = req.body || {};
  if (!id) { const e = new Error("id required"); e.status = 400; throw e; }

  // Owner path
  const owned = await getEstimate(user.oid, id);
  if (owned) {
    await deleteEstimateById(user.oid, id);
    context.res = { status: 200, body: { ok: true } };
    return;
  }

  // Super admin cross-partition delete
  if (user.role === "super_admin") {
    const located = await findEstimateById(id);
    if (!located) { const e = new Error("Estimate not found"); e.status = 404; throw e; }
    await deleteEstimateById(located.partitionKey, located.rowKey);
    context.res = { status: 200, body: { ok: true } };
    return;
  }

  const e = new Error("Not found or not owned"); e.status = 404; throw e;
});
