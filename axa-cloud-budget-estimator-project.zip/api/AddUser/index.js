const { withAuth } = require("../shared/auth");
const { getUserByEmail, upsertUser } = require("../shared/tables");

const VALID_ROLES = new Set(["user", "pricing_admin", "super_admin"]);

module.exports = withAuth(["super_admin"], async (context, req, user) => {
  const body = req.body || {};
  if (!body.name || !body.email || !VALID_ROLES.has(body.role)) {
    const e = new Error("name, email and valid role required"); e.status = 400; throw e;
  }
  const email = String(body.email).toLowerCase().trim();
  const existing = await getUserByEmail(email);
  if (existing) { const e = new Error("User already exists"); e.status = 409; throw e; }
  await upsertUser({
    email,
    name: body.name.trim(),
    role: body.role,
    avatar: body.avatar || body.name.trim().split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2),
    upn: (body.upn || "").toLowerCase().trim(),
    assignedProducts: body.role === "pricing_admin" ? (body.assignedProducts || []) : [],
  });
  context.res = { status: 200, body: { ok: true } };
});