const { withAuth } = require("../shared/auth");
const { getUserByEmail, upsertUser } = require("../shared/tables");

const VALID_ROLES = new Set(["user", "pricing_admin", "super_admin"]);

module.exports = withAuth(["super_admin"], async (context, req, user) => {
  const body = req.body || {};
  if (!body.email) { const e = new Error("email required"); e.status = 400; throw e; }
  const email = String(body.email).toLowerCase().trim();
  const existing = await getUserByEmail(email);
  if (!existing) { const e = new Error("User not found"); e.status = 404; throw e; }

  // Prevent the only super_admin from demoting themselves and locking everyone out
  if (existing.role === "super_admin" && body.role && body.role !== "super_admin" && email === user.email) {
    const e = new Error("Cannot demote yourself — promote another super admin first");
    e.status = 400; throw e;
  }

  const role = body.role && VALID_ROLES.has(body.role) ? body.role : existing.role;
  const name = body.name ? String(body.name).trim() : existing.name;

  // Recompute initials when the name changed and no explicit avatar was sent.
  const nameChanged = name !== existing.name;
  const avatar = body.avatar
    || (nameChanged
        ? name.split(" ").filter(Boolean).map((w) => w[0]).join("").toUpperCase().slice(0, 2)
        : existing.avatar);

  await upsertUser({
    email,
    name,
    role,
    avatar,
    // upsertUser writes the full entity, so the UPN must be carried through
    // explicitly — otherwise every role/name edit silently blanked it and
    // broke UPN-based user lookup at sign-in.
    upn: body.upn !== undefined ? body.upn : existing.upn,
    assignedProducts: role === "pricing_admin"
      ? (body.assignedProducts ?? existing.assignedProducts ?? [])
      : [],
  });
  context.res = { status: 200, body: { ok: true } };
});
