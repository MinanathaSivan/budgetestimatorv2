const { withAuth } = require("../shared/auth");
const { listProducts } = require("../shared/tables");

// Any authenticated application user can read the rate card — the Estimator
// needs it to compute line items.
module.exports = withAuth(async (context, req, user) => {
  const rows = await listProducts();
  context.res = { status: 200, body: rows };
});
