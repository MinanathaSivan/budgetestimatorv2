const { withAuth } = require("../shared/auth");
const { listAwsPrices } = require("../shared/tables");

module.exports = withAuth(async (context, req, user) => {
  const region = (req.query.region || "").trim();
  if (!region) { const e = new Error("region query param required"); e.status = 400; throw e; }

  const rows = await listAwsPrices(region, null);
  context.res = {
    status: 200,
    body: rows.map((r) => ({
      sku: r.sku,
      family: r.family,
      instanceType: r.instanceType,
      vcpus: r.vcpus,
      memoryGb: r.memoryGb,
      storage: r.storage,
      priceUsd: r.priceUsd,
      currency: r.currency,
    })),
  };
});
