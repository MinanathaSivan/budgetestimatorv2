const { withAuth } = require("../shared/auth");
const { listAzurePrices } = require("../shared/tables");

// Returns Azure VM SKUs for the requested region, optionally filtered by family.
// Cache rows are populated by the RefreshAzurePrices timer trigger and the
// admin-only RefreshAzurePricesNow HTTP trigger.
module.exports = withAuth(async (context, req, user) => {
  const region = (req.query.region || "").trim();
  const family = (req.query.family || "").trim();
  if (!region) { const e = new Error("region query param required"); e.status = 400; throw e; }

  const rows = await listAzurePrices(region, family || null);
  // Shape rows the way MpiVmForm expects
  context.res = {
    status: 200,
    body: rows.map((r) => ({
      sku: r.sku,
      family: r.family,
      armSkuName: r.armSkuName,
      productName: r.productName,
      meterName: r.meterName,
      priceUsd: r.priceUsd,
      currency: r.currency,
    })),
  };
});
