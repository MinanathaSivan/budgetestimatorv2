const { withAuth } = require("../shared/auth");
const { listUsers } = require("../shared/tables");

module.exports = withAuth(["super_admin"], async (context, req, user) => {
  const rows = await listUsers();
  context.res = { status: 200, body: rows };
});
