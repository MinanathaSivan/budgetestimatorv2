const { withAuth } = require("../shared/auth");
const { getEstimate, findEstimateById, upsertEstimate } = require("../shared/tables");

module.exports = withAuth(async (context, req, user) => {
  const body = req.body || {};
  if (!body.id) { const e = new Error("id required"); e.status = 400; throw e; }

  // Owner path
  let existing = await getEstimate(user.oid, body.id);
  let ownerOid = user.oid;
  let ownerName = user.name;

  // Super admin can edit any estimate — locate the owning partition
  if (!existing && user.role === "super_admin") {
    const located = await findEstimateById(body.id);
    if (!located) { const e = new Error("Estimate not found"); e.status = 404; throw e; }
    existing = await getEstimate(located.partitionKey, located.rowKey);
    ownerOid = located.partitionKey;
    ownerName = existing?.ownerName || user.name;
  }

  if (!existing) { const e = new Error("Not found or not owned"); e.status = 404; throw e; }

  const entity = {
    id: body.id,
    ownerOid,
    ownerName,
    projectName: (body.projectName || existing.projectName).trim(),
    items: Array.isArray(body.items) ? body.items : existing.items,
    totalMonthlyEur: Number(body.totalMonthlyEur ?? existing.totalMonthlyEur),
    totalAnnualEur: Number(body.totalAnnualEur ?? existing.totalAnnualEur),
    createdAt: existing.createdAt,
    updatedAt: new Date().toISOString(),
  };
  await upsertEstimate(entity);
  context.res = { status: 200, body: entity };
});
