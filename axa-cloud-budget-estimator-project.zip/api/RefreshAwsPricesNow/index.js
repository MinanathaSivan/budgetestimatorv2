// Refreshes ONE AWS region's VM SKU cache per call.
// Same auth pattern as RefreshAzurePricesNow — super_admin session OR shared secret.
//
// Usage from browser console:
//   fetch('/api/RefreshAwsPricesNow?region=eu-central-1', {method:'POST', credentials:'include'})
//     .then(r=>r.json()).then(console.log)

const { refreshAwsRegion, APPROVED_AWS_REGIONS } = require("../shared/awsPricing");
const { authorize } = require("../shared/auth");
const { ensureTables } = require("../shared/tables");

module.exports = async function (context, req) {
  // --- auth: shared secret OR super_admin session --------------------------
  const providedSecret = req.headers["x-refresh-secret"];
  const expectedSecret = process.env.REFRESH_SECRET;
  const hasSecret = expectedSecret && providedSecret && providedSecret === expectedSecret;

  if (!hasSecret) {
    try { await authorize(req, ["super_admin"]); }
    catch (err) {
      context.res = {
        status: err.status || 401,
        headers: { "Content-Type": "application/json" },
        body: { error: "Unauthorized — super_admin session or valid x-refresh-secret header required" },
      };
      return;
    }
  }

  // --- region selection ---------------------------------------------------
  const region = (req.query.region || "").trim();
  if (!region) {
    context.res = {
      status: 400,
      headers: { "Content-Type": "application/json" },
      body: {
        error: "region query parameter required",
        approvedRegions: APPROVED_AWS_REGIONS,
        example: "/api/RefreshAwsPricesNow?region=eu-central-1",
      },
    };
    return;
  }

  if (!APPROVED_AWS_REGIONS.includes(region)) {
    context.res = {
      status: 400,
      headers: { "Content-Type": "application/json" },
      body: {
        error: `region '${region}' not in approved AWS regions`,
        approvedRegions: APPROVED_AWS_REGIONS,
      },
    };
    return;
  }

  // --- refresh ------------------------------------------------------------
  const started = Date.now();
  try {
    await ensureTables();
    const result = await refreshAwsRegion(context, region);
    context.res = {
      status: 200,
      headers: { "Content-Type": "application/json" },
      body: { ok: true, provider: "AWS", ...result, elapsedMs: Date.now() - started },
    };
  } catch (err) {
    context.log.error(`AWS refresh ${region} failed: ${err.message}\n${err.stack}`);
    context.res = {
      status: 500,
      headers: { "Content-Type": "application/json" },
      body: { error: err.message, region, elapsedMs: Date.now() - started },
    };
  }
};
