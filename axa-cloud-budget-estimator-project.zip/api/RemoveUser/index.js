const { withAuth } = require("../shared/auth");
const { deleteUser } = require("../shared/tables");

module.exports = withAuth(["super_admin"], async (context, req, user) => {
  const { email } = req.body || {};
  if (!email) { const e = new Error("email required"); e.status = 400; throw e; }
  const target = String(email).toLowerCase().trim();
  if (target === user.email) {
    const e = new Error("Cannot remove yourself"); e.status = 400; throw e;
  }
  await deleteUser(target);
  context.res = { status: 200, body: { ok: true } };
});
