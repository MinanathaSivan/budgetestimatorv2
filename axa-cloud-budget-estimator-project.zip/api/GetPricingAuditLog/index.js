const { withAuth } = require("../shared/auth");
const { listAudit } = require("../shared/tables");

module.exports = withAuth(["super_admin", "pricing_admin"], async (context, req, user) => {
  const rows = await listAudit(200);
  context.res = { status: 200, body: rows };
});
