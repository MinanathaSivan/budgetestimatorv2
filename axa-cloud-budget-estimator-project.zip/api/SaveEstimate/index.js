const { v4: uuidv4 } = require("uuid");
const { withAuth } = require("../shared/auth");
const { upsertEstimate } = require("../shared/tables");

module.exports = withAuth(async (context, req, user) => {
  const body = req.body || {};
  if (!body.projectName || !Array.isArray(body.items) || body.items.length === 0) {
    const e = new Error("projectName and non-empty items required"); e.status = 400; throw e;
  }
  const now = new Date().toISOString();
  const entity = {
    id: body.id || uuidv4(),
    ownerOid: user.oid,
    ownerName: user.name,
    projectName: body.projectName.trim(),
    items: body.items,
    totalMonthlyEur: Number(body.totalMonthlyEur || 0),
    totalAnnualEur: Number(body.totalAnnualEur || 0),
    createdAt: body.createdAt || now,
    updatedAt: now,
  };
  await upsertEstimate(entity);
  context.res = { status: 200, body: entity };
});
