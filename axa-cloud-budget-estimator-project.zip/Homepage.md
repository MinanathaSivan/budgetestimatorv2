# AXA Cloud Budget Estimator

*Content for the Cloud Broker homepage — prepared by the Cloud Broker Asia team.*

-----

## Overview

The **AXA Cloud Budget Estimator** is a self-service web application that enables AXA entity teams to estimate cloud infrastructure costs before deployment. It supports better budget planning, faster decision-making, and consistent cost visibility for new initiatives, migrations, and ongoing project work.

## Key Features

- **Multi-product pricing coverage** — estimate costs for MPI Virtual Machines, NAS / Fileshare storage, POD (Platform-on-Demand) components, and Terraform Workspaces from a single interface.
- **Real-time cost calculations** — interactive estimates that update as users adjust configurations.
- **Component-level breakdown** — see exactly which elements drive the cost, enabling optimization discussions early in the planning cycle.
- **Modern, responsive interface** — built as a React + Vite single-page application for a fast, clean user experience.
- **Centralized and extensible** — backed by Azure Functions, making it straightforward to add new products and pricing models as the platform evolves.

## Target Users

- **AXA** — All
- **Project managers and PMOs** preparing budgets for cloud-related initiatives
- **Solution architects** sizing and planning workload deployments
- **FinOps and finance stakeholders** requiring cost visibility ahead of commitment

## Typical Use Cases

- Producing cost estimates for new application onboardings or cloud migrations
- Comparing configuration options to identify cost-effective designs
- Generating budget figures for project approval and forecasting cycles
- Validating proposed infrastructure scope against approved budget envelopes

## Owner

Cloud Broker Asia team

## Access

The application is currently being prepared for deployment to a dedicated subscription under the AXA 365 tenant. The access link will be shared in **early-to-mid July**, once deployment and security review are complete.

-----

*Please reach out to the Cloud Broker Asia team for any questions on content, scope, or upcoming product coverage.*